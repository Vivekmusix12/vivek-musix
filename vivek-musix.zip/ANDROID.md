# VIVEK'S MUSIX — standalone Android app

The APK contains the complete app (same design, search, player, queue, liked, history, downloads, Jam).
It does NOT load the website. Website and APK are two separate clients using the same music API and backend.

## Build
1. Install Node/Bun, JDK 17+, Android Studio.
2. `bun install`
3. `bun run build:android`  (builds the app, creates the start page, copies it into `android/`)
4. Open the `android/` folder in Android Studio → Build → Generate Signed App Bundle / APK.

Re-run step 3 after every app change.

## Native playback
Media3 MediaSessionService (`VivekPlaybackService` + `WebBridgePlayer`) runs as a foreground media service:
screen-off and background playback, lock-screen/notification controls (play/pause, prev, next, seek),
Bluetooth headset buttons. It mirrors the single app audio player — no second player.
Set the app's Battery setting to "Unrestricted" on Xiaomi/Vivo/Oppo/Samsung.

Note: the Vibe Engine AI suggestions need the web server, so in the APK it falls back to plain mood search.
