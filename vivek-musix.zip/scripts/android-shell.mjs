const mod = await import(process.cwd()+"/dist/server/index.mjs");
const h = mod.default;
const res = await h.fetch(new Request("http://localhost/"), {}, {waitUntil(){},passThroughOnException(){}});
const html = await res.text();
console.log(res.status, html.length, html.slice(0,300));
await Bun.write("dist/client/index.html", html);
