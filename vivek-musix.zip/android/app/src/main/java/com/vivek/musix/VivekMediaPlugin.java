package com.vivek.musix;

import android.content.Intent;
import android.os.SystemClock;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** JS <-> native bridge: the web player reports its state, native media buttons send commands back. */
@CapacitorPlugin(name = "VivekMedia")
public class VivekMediaPlugin extends Plugin {
    private boolean serviceStarted = false;

    @Override
    public void load() {
        Bridge.listener = (action, position) -> {
            JSObject o = new JSObject();
            o.put("action", action);
            o.put("position", position);
            notifyListeners("command", o, true);
        };
    }

    @PluginMethod
    public void update(PluginCall call) {
        if (call.hasOption("title")) Bridge.title = call.getString("title", "");
        if (call.hasOption("artist")) Bridge.artist = call.getString("artist", "");
        if (call.hasOption("album")) Bridge.album = call.getString("album", "");
        if (call.hasOption("artwork")) Bridge.artwork = call.getString("artwork", null);
        if (call.hasOption("duration")) Bridge.durationMs = (long) (call.getDouble("duration", 0.0) * 1000);
        if (call.hasOption("position")) {
            Bridge.positionMs = (long) (call.getDouble("position", 0.0) * 1000);
            Bridge.positionAt = SystemClock.elapsedRealtime();
        }
        if (call.hasOption("playing")) {
            boolean p = Boolean.TRUE.equals(call.getBoolean("playing", false));
            if (p != Bridge.playing) {
                Bridge.positionMs = Bridge.currentPositionMs();
                Bridge.positionAt = SystemClock.elapsedRealtime();
            }
            Bridge.playing = p;
            if (p) ensureService();
        }
        Bridge.changed();
        call.resolve();
    }

    private void ensureService() {
        if (serviceStarted) return;
        try {
            getContext().startService(new Intent(getContext(), VivekPlaybackService.class));
            serviceStarted = true;
        } catch (Exception ignored) { /* app in background; retried on next play */ }
    }
}
