package com.vivek.musix;

import android.os.SystemClock;

/** Shared now-playing state between the web player (via VivekMediaPlugin) and the Media3 service. */
final class Bridge {
    interface Listener { void onCommand(String action, double position); }

    static volatile String title = "";
    static volatile String artist = "";
    static volatile String album = "";
    static volatile String artwork = null;
    static volatile long durationMs = 0;
    static volatile long positionMs = 0;
    static volatile long positionAt = 0;
    static volatile boolean playing = false;
    static volatile Listener listener;
    static volatile Runnable onChange;

    private Bridge() {}

    static long currentPositionMs() {
        long p = positionMs + (playing ? SystemClock.elapsedRealtime() - positionAt : 0);
        if (durationMs > 0 && p > durationMs) p = durationMs;
        return Math.max(0, p);
    }

    static void changed() {
        Runnable r = onChange;
        if (r != null) r.run();
    }

    static void command(String action, double position) {
        Listener l = listener;
        if (l != null) l.onCommand(action, position);
    }
}
