package com.vivek.musix;

import android.net.Uri;
import android.os.Looper;
import androidx.annotation.NonNull;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.SimpleBasePlayer;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.common.util.Util;
import com.google.common.collect.ImmutableList;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

/**
 * Media3 player that represents the app's single global audio player (the one inside the web UI).
 * It owns no second decoder: lock screen / notification / Bluetooth commands are forwarded to the
 * web player, and its state mirrors what the web player reports. This keeps exactly ONE audio player.
 */
@UnstableApi
final class WebBridgePlayer extends SimpleBasePlayer {
    private static final Commands COMMANDS = new Commands.Builder().addAll(
            COMMAND_PLAY_PAUSE, COMMAND_STOP,
            COMMAND_SEEK_IN_CURRENT_MEDIA_ITEM,
            COMMAND_SEEK_TO_NEXT, COMMAND_SEEK_TO_NEXT_MEDIA_ITEM,
            COMMAND_SEEK_TO_PREVIOUS, COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM,
            COMMAND_GET_CURRENT_MEDIA_ITEM, COMMAND_GET_TIMELINE, COMMAND_GET_METADATA
    ).build();

    WebBridgePlayer(Looper looper) { super(looper); }

    void refresh() { invalidateState(); }

    @NonNull
    @Override
    protected State getState() {
        String art = Bridge.artwork;
        MediaMetadata md = new MediaMetadata.Builder()
                .setTitle(Bridge.title)
                .setArtist(Bridge.artist)
                .setAlbumTitle(Bridge.album)
                .setArtworkUri(art == null || art.isEmpty() ? null : Uri.parse(art))
                .build();
        String id = Bridge.title + "|" + Bridge.artist;
        MediaItem item = new MediaItem.Builder().setMediaId(id).setMediaMetadata(md).build();
        MediaItemData data = new MediaItemData.Builder(id)
                .setMediaItem(item)
                .setDurationUs(Bridge.durationMs > 0 ? Util.msToUs(Bridge.durationMs) : C.TIME_UNSET)
                .setIsSeekable(true)
                .build();
        return new State.Builder()
                .setAvailableCommands(COMMANDS)
                .setPlayWhenReady(Bridge.playing, PLAY_WHEN_READY_CHANGE_REASON_USER_REQUEST)
                .setPlaybackState(Bridge.title.isEmpty() ? STATE_IDLE : STATE_READY)
                .setPlaylist(ImmutableList.of(data))
                .setCurrentMediaItemIndex(0)
                .setContentPositionMs(Bridge.currentPositionMs())
                .build();
    }

    @NonNull
    @Override
    protected ListenableFuture<?> handleSetPlayWhenReady(boolean playWhenReady) {
        Bridge.command(playWhenReady ? "play" : "pause", 0);
        return Futures.immediateVoidFuture();
    }

    @NonNull
    @Override
    protected ListenableFuture<?> handleSeek(int mediaItemIndex, long positionMs, int seekCommand) {
        switch (seekCommand) {
            case COMMAND_SEEK_TO_NEXT:
            case COMMAND_SEEK_TO_NEXT_MEDIA_ITEM:
                Bridge.command("next", 0);
                break;
            case COMMAND_SEEK_TO_PREVIOUS:
            case COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM:
                Bridge.command("prev", 0);
                break;
            default:
                Bridge.command("seek", positionMs / 1000.0);
        }
        return Futures.immediateVoidFuture();
    }

    @NonNull
    @Override
    protected ListenableFuture<?> handleStop() {
        Bridge.command("pause", 0);
        return Futures.immediateVoidFuture();
    }
}
