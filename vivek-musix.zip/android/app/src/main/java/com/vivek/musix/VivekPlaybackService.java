package com.vivek.musix;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

/**
 * Android foreground media service (Media3). Shows the media notification + lock-screen controls,
 * receives Bluetooth / headset buttons, and keeps the app process alive while music plays with the
 * screen off or the app minimized.
 */
@UnstableApi
public class VivekPlaybackService extends MediaSessionService {
    private MediaSession session;
    private WebBridgePlayer player;

    // Headphones unplugged / Bluetooth disconnected -> pause instead of blasting the phone speaker
    private final BroadcastReceiver noisy = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(i.getAction())) Bridge.command("pause", 0);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        player = new WebBridgePlayer(Looper.getMainLooper());
        Handler main = new Handler(Looper.getMainLooper());
        Bridge.onChange = () -> main.post(() -> { if (player != null) player.refresh(); });

        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        MediaSession.Builder b = new MediaSession.Builder(this, player);
        if (launch != null) {
            b.setSessionActivity(PendingIntent.getActivity(this, 0, launch,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        }
        session = b.build();
        ContextCompat.registerReceiver(this, noisy,
                new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY), ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    @Nullable
    @Override
    public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) { return session; }

    @Override
    public void onTaskRemoved(@Nullable Intent rootIntent) {
        // The music lives inside the app screen, so when the app is swiped away, stop cleanly.
        stopSelf();
    }

    @Override
    public void onDestroy() {
        try { unregisterReceiver(noisy); } catch (Exception ignored) {}
        Bridge.onChange = null;
        if (session != null) { session.release(); session = null; }
        if (player != null) { player.release(); player = null; }
        super.onDestroy();
    }
}
