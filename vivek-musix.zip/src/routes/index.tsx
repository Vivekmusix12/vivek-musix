import { createFileRoute } from "@tanstack/react-router";
import VivekMusix from "@/components/VivekMusix";
import { AppErrorBoundary } from "@/components/AppErrorBoundary";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VIVEK'S MUSIX — Stream, Search & Vibe" },
      { name: "description", content: "VIVEK'S MUSIX: search songs, mood mixes, lyrics, 14 themes and background play. Powered by VIVEK." },
      { property: "og:title", content: "VIVEK'S MUSIX — Stream, Search & Vibe" },
      { property: "og:description", content: "Search songs, mood mixes, live lyrics, 14 themes and background play. Powered by VIVEK." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  return <AppErrorBoundary><VivekMusix /></AppErrorBoundary>;
}
