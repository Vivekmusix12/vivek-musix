import { ClientOnly } from "@tanstack/react-router";
import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { nativeHandlers, nativeMeta, nativePosition, nativeState } from "@/lib/native-media";
import {
  Play, Pause, SkipBack, SkipForward, Search, Shuffle, Repeat, Repeat1, Heart, Volume2, VolumeX,
  Palette, Mic2, ListMusic, X, Sun, Sunrise, Sunset, Moon,
  Frame, Disc3, Loader2, ChevronDown, Music2, Download, CheckCircle2, MapPin, Flame,
  WifiOff, HeartHandshake, PartyPopper, CloudRain, Dumbbell, Coffee, Zap, Car, Sparkles, Gauge, Leaf, Brain, Guitar, Headphones,
  Wand2, History, Clock, Timer, MonitorDown, LayoutDashboard, Home as HomeIcon,
  Share2, Users, Copy, LogOut,
} from "lucide-react";
import { saveDownload, getDownload, removeDownload, listDownloads, fetchWithProgress } from "@/lib/offline";
import { getMoodQueries } from "@/lib/ai-mood.functions";
import { useJam, type JamMsg } from "@/lib/jam";

type SoundMode = "auto" | "mass" | "vocal" | "hifi" | "flat";
// gains for: sub-bass shelf, punch, mud cut, vocal presence, de-harsh, air
const SOUND_MODES: { id: SoundMode; name: string; hint: string; g: number[]; pre: number }[] = [
  // Gentle, musical curves. "pre" leaves headroom so boosts never clip.
  { id: "auto", name: "Auto Studio", hint: "Balanced bass + clear vocals", g: [3.5, 2.2, -1.8, 1.6, -0.8, 1.4], pre: 0.92 },
  { id: "mass", name: "Mass Bass", hint: "Deep, powerful beats", g: [5.5, 3.2, -2.2, 1.4, -1, 1], pre: 0.84 },
  { id: "vocal", name: "Crystal Vocals", hint: "Clear voice", g: [1.5, 0.8, -2, 2.6, -1, 1.6], pre: 0.92 },
  { id: "hifi", name: "Hi-Fi", hint: "Premium detail + depth", g: [2.5, 1.4, -1, 1.2, -0.6, 2], pre: 0.94 },
  { id: "flat", name: "Original", hint: "Untouched", g: [0, 0, 0, 0, 0, 0], pre: 1 },
];
type EqNodes = { filters: BiquadFilterNode[]; pre: GainNode };
const SITUATIONS = ["Late night drive", "Gym mass beats", "Rainy evening chai", "Heartbreak healing", "Wedding dance floor", "Study focus", "Morning devotional", "Road trip with friends"];

const API = "https://jiosavan-api2.vercel.app/api";

type Img = { quality: string; url: string };
type Song = {
  id: string; name: string; duration: number | null; year?: string | null;
  album?: { name?: string | null };
  artists?: { primary?: { name: string }[] };
  image?: Img[]; downloadUrl?: Img[];
};
type Album = { id: string; name: string; year?: string | null; image?: Img[]; artists?: { primary?: { name: string }[] } };
type LyricLine = { t: number; text: string };

const THEMES = [
  { id: "vivek", name: "VIVEK Noir", c: ["#0c0b12", "#9b7bff"] },
  { id: "midnight", name: "Midnight", c: ["#1a1530", "#3ddc97"] },
  { id: "sunset", name: "Sunset", c: ["#2b1510", "#ff9a3c"] },
  { id: "ocean", name: "Ocean", c: ["#0f1f33", "#4cc9f0"] },
  { id: "neon", name: "Neon", c: ["#140a18", "#ff2e93"] },
  { id: "forest", name: "Forest", c: ["#10221a", "#9be15d"] },
  { id: "royal", name: "Royal", c: ["#1b1238", "#f5c451"] },
  { id: "crimson", name: "Crimson", c: ["#1f0f10", "#e63946"] },
  { id: "mono", name: "Mono", c: ["#151515", "#f2f2f2"] },
  { id: "aurora", name: "Aurora", c: ["#0e2228", "#5ef2c5"] },
  { id: "gold", name: "Gold", c: ["#17140c", "#f0c14b"] },
  { id: "cyber", name: "Cyber", c: ["#161a0c", "#d6ff3f"] },
  { id: "sakura", name: "Sakura", c: ["#fbeef3", "#e8508a"] },
  { id: "paper", name: "Paper", c: ["#f7f2e8", "#b8542b"] },
  { id: "lavender", name: "Lavender", c: ["#efe8f8", "#7b3fd1"] },
] as const;

const MOODS = [
  { id: "love", name: "Love", Icon: HeartHandshake, q: "love romantic songs" },
  { id: "party", name: "Party", Icon: PartyPopper, q: "party dance hits" },
  { id: "sad", name: "Sad", Icon: CloudRain, q: "sad heartbreak songs" },
  { id: "workout", name: "Workout", Icon: Dumbbell, q: "workout gym motivation songs" },
  { id: "chill", name: "Chill", Icon: Coffee, q: "chill lofi songs" },
  { id: "mass", name: "Mass", Icon: Zap, q: "telugu mass songs" },
  { id: "drive", name: "Road Trip", Icon: Car, q: "road trip songs" },
  { id: "devotional", name: "Devotional", Icon: Sparkles, q: "devotional bhakti songs" },
  { id: "melody", name: "Melody", Icon: Leaf, q: "soulful melody songs" },
  { id: "focus", name: "Focus", Icon: Brain, q: "instrumental focus music" },
  { id: "retro", name: "Retro", Icon: Guitar, q: "old classic retro hits" },
  { id: "sleep", name: "Sleep", Icon: Moon, q: "calm sleep songs" },
] as const;

const SINGERS = ["Sid Sriram", "Arijit Singh", "Shreya Ghoshal", "Anirudh Ravichander", "S. P. Balasubrahmanyam", "Armaan Malik", "Thaman S", "Devi Sri Prasad", "A.R. Rahman", "Mangli", "Diljit Dosanjh", "Jubin Nautiyal"];

const FRAMES = ["vinyl", "polaroid", "neon", "classic", "circle"] as const;
type FrameKind = (typeof FRAMES)[number];

const decode = (s?: string | null) => {
  if (!s) return "";
  if (typeof document === "undefined") return s;
  const t = document.createElement("textarea");
  t.innerHTML = s;
  return t.value;
};
const artistOf = (s?: { artists?: { primary?: { name: string }[] } } | null) =>
  decode(s?.artists?.primary?.map((a) => a.name).slice(0, 3).join(", ") ?? "Unknown");
const imgOf = (s?: { image?: Img[] } | null, hi = true) => {
  const list = s?.image ?? [];
  return (hi ? list[list.length - 1] : list[1] ?? list[0])?.url ?? "";
};
const audioOf = (s: Song) => {
  const l = s.downloadUrl ?? [];
  return (l.find((d) => d.quality === "320kbps") ?? l[l.length - 1])?.url ?? "";
};
const fmt = (n: number) => {
  if (!isFinite(n) || n < 0) return "0:00";
  const m = Math.floor(n / 60);
  const s = Math.floor(n % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
};

function timeMood(d = new Date()) {
  const h = d.getHours();
  if (h >= 5 && h < 12) return { key: "morning", greet: "Good Morning", line: "Rise & shine — fresh beats to kick-start your day.", Icon: Sunrise, query: "morning fresh telugu hindi hits" };
  if (h >= 12 && h < 17) return { key: "afternoon", greet: "Good Afternoon", line: "Keep the energy high with upbeat hits.", Icon: Sun, query: "trending upbeat hits" };
  if (h >= 17 && h < 21) return { key: "evening", greet: "Good Evening", line: "Golden-hour melodies to wind down.", Icon: Sunset, query: "evening chill romantic" };
  return { key: "night", greet: "Good Night", line: "Soft melodies for a calm, starry night.", Icon: Moon, query: "night lofi soft melody" };
}

// in-memory cache + in-flight dedupe + timeout: fast repeat views, fewer API calls under heavy use
const jsonCache = new Map<string, { at: number; p: Promise<unknown> }>();
const CACHE_MS = 10 * 60 * 1000;
const failCache = new Map<string, number>();
const FAIL_MS = 20 * 1000;
async function getJSON<T>(url: string): Promise<T | null> {
  const hit = jsonCache.get(url);
  if (hit && Date.now() - hit.at < CACHE_MS) return hit.p as Promise<T | null>;
  const failAt = failCache.get(url);
  if (failAt && Date.now() - failAt < FAIL_MS) return null;
  const p = (async () => {
    for (let attempt = 0; attempt < 3; attempt++) {
      if (typeof navigator !== "undefined" && navigator.onLine === false) return null;
      try {
        const r = await fetch(url, { signal: AbortSignal.timeout(10000) });
        if (r.ok) return (await r.json()) as T;
        if (r.status !== 429 && r.status < 500) return null;
        console.warn(`[VIVEK] API ${r.status}, retrying`, url);
      } catch (e) { console.warn("[VIVEK] API request failed", e); }
      if (attempt < 2) await new Promise((res) => setTimeout(res, 700 * 2 ** attempt + Math.random() * 300));
    }
    return null;
  })();
  jsonCache.set(url, { at: Date.now(), p });
  const v = await p;
  if (v === null) { jsonCache.delete(url); failCache.set(url, Date.now()); if (failCache.size > 200) failCache.clear(); }
  if (jsonCache.size > 300) { const k = jsonCache.keys().next().value; if (k) jsonCache.delete(k); }
  return v;
}
async function searchSongs(q: string, limit = 20) {
  const j = await getJSON<{ data?: { results?: Song[] } }>(`${API}/search/songs?query=${encodeURIComponent(q)}&limit=${limit}`);
  return j?.data?.results ?? [];
}
async function searchAlbums(q: string) {
  const j = await getJSON<{ data?: { results?: Album[] } }>(`${API}/search/albums?query=${encodeURIComponent(q)}&limit=12`);
  return j?.data?.results ?? [];
}
async function albumSongs(id: string) {
  const j = await getJSON<{ data?: { songs?: Song[] } }>(`${API}/albums?id=${encodeURIComponent(id)}`);
  return j?.data?.songs ?? [];
}
async function artistImage(name: string) {
  const j = await getJSON<{ data?: { results?: { image?: Img[] }[] } }>(`${API}/search/artists?query=${encodeURIComponent(name)}&limit=1`);
  return imgOf(j?.data?.results?.[0] ?? null, false);
}
async function suggestions(id: string) {
  const j = await getJSON<{ data?: Song[] }>(`${API}/songs/${encodeURIComponent(id)}/suggestions?limit=15`);
  return Array.isArray(j?.data) ? j!.data! : [];
}
async function fetchLyrics(s: Song): Promise<{ synced: LyricLine[]; plain: string } | null> {
  const track = decode(s.name).replace(/\(.*?\)/g, "").trim();
  const artist = decode(s.artists?.primary?.[0]?.name ?? "");
  const res = await getJSON<{ syncedLyrics?: string; plainLyrics?: string }[]>(
    `https://lrclib.net/api/search?track_name=${encodeURIComponent(track)}&artist_name=${encodeURIComponent(artist)}`,
  );
  const hit = res?.find((r) => r.syncedLyrics) ?? res?.[0];
  if (!hit) return null;
  const synced: LyricLine[] = [];
  (hit.syncedLyrics ?? "").split("\n").forEach((line) => {
    const m = line.match(/^\[(\d+):(\d+(?:\.\d+)?)\](.*)$/);
    if (m) synced.push({ t: Number(m[1]) * 60 + Number(m[2]), text: (m[3] ?? "").trim() });
  });
  return { synced, plain: hit.plainLyrics ?? "" };
}

/* ---------------- Intro ---------------- */
function Intro({ onDone }: { onDone: () => void }) {
  const [place, setPlace] = useState<string>("Finding your location…");
  useEffect(() => {
    if (!navigator.geolocation) { setPlace(""); return; }
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const { latitude, longitude } = pos.coords;
      const j = await getJSON<{ city?: string; locality?: string; principalSubdivision?: string; countryName?: string }>(
        `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`);
      const name = [j?.city || j?.locality, j?.principalSubdivision].filter(Boolean).join(", ");
      setPlace(name ? `Live from ${name}` : `Live · ${latitude.toFixed(2)}, ${longitude.toFixed(2)}`);
    }, () => setPlace(""), { timeout: 6000 });
  }, []);
  const doneRef = useRef(onDone); doneRef.current = onDone;
  const [out, setOut] = useState(false);
  const finish = () => { if (out) return; setOut(true); setTimeout(() => doneRef.current(), 520); };
  const finishRef = useRef(finish); finishRef.current = finish;
  useEffect(() => {
    const t = setTimeout(() => finishRef.current(), 4200);
    return () => clearTimeout(t);
  }, []);
  return (
    <button onClick={finish} className={`fixed inset-0 z-[100] flex flex-col items-center justify-center overflow-hidden bg-background transition-opacity duration-500 ${out ? "pointer-events-none opacity-0" : "opacity-100"}`} style={{ backgroundImage: "radial-gradient(ellipse at top, color-mix(in oklab, var(--primary) 25%, transparent), transparent 60%), radial-gradient(ellipse at bottom right, color-mix(in oklab, var(--accent) 30%, transparent), transparent 55%)" }} aria-label="Skip intro">
      <div className="vm-pulse absolute h-[60vmin] w-[60vmin] rounded-full bg-primary/20 blur-3xl" />
      <div className="vm-pulse absolute h-[40vmin] w-[40vmin] translate-x-20 rounded-full bg-accent/20 blur-3xl" style={{ animationDelay: "1s" }} />
      <div className={`relative flex flex-col items-center transition-[opacity,transform] duration-500 ${out ? "scale-95 opacity-0" : ""}`}>
        <div className="relative mb-6 flex h-16 items-end gap-1.5">
          {Array.from({ length: 9 }).map((_, i) => (
            <span key={i} className="vm-bar w-2 rounded-full bg-primary" style={{ height: 64, animationDelay: `${i * 0.1}s` }} />
          ))}
        </div>
        <h1 className="vm-intro font-display relative text-5xl font-extrabold text-foreground sm:text-7xl">
          VIVEK'S <span className="text-primary">MUSIX</span>
        </h1>
        <Signature className="relative mt-4 h-14 w-56" />
        {place && (
          <span className="animate-fade-in relative mt-6 flex items-center gap-2 rounded-full border border-primary/40 bg-card/70 px-4 py-2 text-sm text-foreground backdrop-blur-xl">
            <span className="relative flex h-2.5 w-2.5"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" /><span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-primary" /></span>
            <MapPin size={14} className="text-primary" /> {place}
          </span>
        )}
      </div>
    </button>
  );
}

function LiveDot() {
  return <span className="relative inline-flex h-2 w-2"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" /><span className="relative inline-flex h-2 w-2 rounded-full bg-primary" /></span>;
}

function Signature({ className = "" }: { className?: string }) {
  return (
    <div className={`flex flex-col items-center ${className}`}>
      <span className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.4em] text-muted-foreground"><LiveDot /> powered by</span>
      <svg viewBox="0 0 220 50" className="vm-sign h-full w-full text-primary" fill="none" style={{ filter: "drop-shadow(0 0 6px var(--primary))" }}>
        <path d="M10 12 L28 40 L44 10 M54 14 L54 40 M64 12 L82 40 L98 10 M110 12 L110 40 M110 26 Q122 14 132 12 M110 26 Q124 34 136 40 M146 40 Q140 20 150 14 Q160 10 158 24 Q154 36 166 40 M176 44 Q196 30 212 18"
          stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </div>
  );
}

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`flex min-w-0 items-center ${compact ? "gap-2" : "gap-2.5 sm:gap-3"}`}>
      <span className={`flex shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent text-primary-foreground shadow-lg ${compact ? "h-9 w-9" : "h-10 w-10"}`}><Disc3 className="vm-spin" size={compact ? 19 : 22} /></span>
      <div className="min-w-0 leading-none">
        <h1 className={`font-display font-extrabold ${compact ? "text-sm leading-tight" : "whitespace-nowrap text-base tracking-wide min-[400px]:text-lg sm:text-2xl"}`}>VIVEK'S <span className="text-primary">MUSIX</span></h1>
        <p className={`mt-1.5 flex items-center gap-1.5 text-[9px] uppercase text-muted-foreground ${compact ? "tracking-[0.13em]" : "whitespace-nowrap tracking-[0.25em] sm:text-[10px] sm:tracking-[0.3em]"}`}><LiveDot /> powered by <span className="vm-shimmer font-bold">VIVEK</span></p>
      </div>
    </div>
  );
}

/* ---------------- Artwork frame ---------------- */
function Artwork({ src, frame, playing, size = "lg" }: { src: string; frame: FrameKind; playing: boolean; size?: "lg" | "sm" }) {
  const dim = size === "lg" ? "h-[min(64vw,30vh,22rem)] w-[min(64vw,30vh,22rem)] lg:h-[min(34vw,30vh,26rem)] lg:w-[min(34vw,30vh,26rem)]" : "w-12 h-12";
  const img = src ? <img src={src} alt="" className="h-full w-full object-cover" /> : <div className="flex h-full w-full items-center justify-center bg-muted"><Music2 className="text-muted-foreground" /></div>;
  if (size === "sm") return <div className={`${dim} shrink-0 overflow-hidden rounded-md`}>{img}</div>;
  switch (frame) {
    case "vinyl":
      return (
        <div className={`${dim} vm-spin ${playing ? "" : "vm-paused"} relative rounded-full bg-foreground/90 p-6 shadow-2xl`}
          style={{ backgroundImage: "repeating-radial-gradient(circle, transparent 0 3px, color-mix(in oklab, var(--background) 60%, transparent) 3px 4px)" }}>
          <div className="h-full w-full overflow-hidden rounded-full ring-4 ring-background">{img}</div>
          <div className="absolute left-1/2 top-1/2 h-5 w-5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-background ring-2 ring-primary" />
        </div>
      );
    case "polaroid":
      return (
        <div className="-rotate-2 rounded-sm bg-card p-3 pb-12 shadow-2xl ring-1 ring-border">
          <div className={`${dim} overflow-hidden`}>{img}</div>
          <p className="font-display mt-3 text-center text-sm text-muted-foreground">VIVEK'S MUSIX</p>
        </div>
      );
    case "neon":
      return (
        <div className={`${dim} overflow-hidden rounded-3xl ring-4 ring-primary`} style={{ boxShadow: "0 0 40px var(--primary), 0 0 90px color-mix(in oklab, var(--accent) 60%, transparent)" }}>{img}</div>
      );
    case "circle":
      return (
        <div className="rounded-full bg-gradient-to-br from-primary to-accent p-1.5 shadow-2xl">
          <div className={`${dim} overflow-hidden rounded-full ring-4 ring-background`}>{img}</div>
        </div>
      );
    default:
      return (
        <div className="rounded-xl border-[10px] border-card bg-card p-1 shadow-2xl ring-1 ring-border" style={{ outline: "2px solid var(--primary)", outlineOffset: 4 }}>
          <div className={`${dim} overflow-hidden rounded-md`}>{img}</div>
        </div>
      );
  }
}

/* ---------------- Main ---------------- */
const DISCOVER: [string, (l: string) => string][] = [
  ["Fresh releases", (l) => `new ${l} songs 2026`],
  ["Melody hits", (l) => `${l} melody songs`],
  ["Mass beats", (l) => (l === "telugu" ? "telugu mass songs" : l === "tamil" ? "tamil kuthu songs" : `${l} mass dance songs`)],
  ["Lo-fi chill", (l) => `${l} lofi`],
  ["Love songs", (l) => `${l} romantic love songs`],
  ["Sad songs", (l) => `${l} sad songs`],
  ["Devotional", (l) => `${l} devotional songs`],
  ["Party", (l) => `${l} party songs`],
  ["Workout", (l) => `${l} workout gym songs`],
];

export default function VivekMusix() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [intro, setIntro] = useState(true);
  const [speed, setSpeed] = useState(1);
  const fadeRef = useRef<GainNode | null>(null);
  const speedRef = useRef(1);
  const [theme, setTheme] = useState<string>("vivek");
  const [frame, setFrame] = useState<FrameKind>("vinyl");
  // Keep server and first client render identical; resolve the local greeting after hydration.
  const [mood, setMood] = useState(() => timeMood(new Date(2000, 0, 1, 12)));
  const [greeting, setGreeting] = useState<string | null>(null);

  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Song[]>([]);
  const [albums, setAlbums] = useState<Album[]>([]);
  const [home, setHome] = useState<Song[]>([]);
  const [loading, setLoading] = useState(false);

  const [queue, setQueue] = useState<Song[]>([]);
  const [idx, setIdx] = useState(-1);
  const [related, setRelated] = useState<Song[]>([]);
  const [playing, setPlaying] = useState(false);
  // playback speed (remembered)
  useEffect(() => { const v = Number(localStorage.getItem("vm-speed")); if (v >= 0.5 && v <= 2) setSpeed(v); }, []);
  useEffect(() => {
    speedRef.current = speed; localStorage.setItem("vm-speed", String(speed));
    const a = audioRef.current; if (a) { a.playbackRate = speed; a.defaultPlaybackRate = speed; (a as HTMLAudioElement & { preservesPitch?: boolean }).preservesPitch = true; }
  }, [speed]);
  // real listening time: only seconds actually heard count (2 min of a 3 min song = 2 min)
  const [listen, setListen] = useState<{ total: number; songs: Record<string, number> }>({ total: 0, songs: {} });
  const listenRef = useRef(listen);
  useEffect(() => { try { const l = localStorage.getItem("vm-listen"); if (l) { const v = JSON.parse(l) as typeof listen; listenRef.current = v; setListen(v); } } catch { /* ignore */ } }, []);
  const [buffering, setBuffering] = useState(false);
  const [time, setTime] = useState(0);
  const [dur, setDur] = useState(0);
  const [volume, setVolume] = useState(0.9);
  const [muted, setMuted] = useState(false);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState<"off" | "all" | "one">("off");
  const [liked, setLiked] = useState<Song[]>([]);
  const [downloads, setDownloads] = useState<Song[]>([]);
  const [dlProgress, setDlProgress] = useState<Record<string, number>>({});
  const [trending, setTrending] = useState<Song[]>([]);
  const [oldies, setOldies] = useState<Song[]>([]);
  const [singerImgs, setSingerImgs] = useState<Record<string, string>>({});
  const [browse, setBrowse] = useState<{ title: string; songs: Song[]; loading: boolean } | null>(null);
  const [playlist, setPlaylist] = useState<{ title: string; img?: string | undefined; songs: Song[]; loading: boolean } | null>(null);
  const [online, setOnline] = useState(true);
  const [playToken, setPlayToken] = useState(0);
  const [lang, setLang] = useState<"telugu" | "hindi" | "tamil" | "malayalam" | "kannada" | "english">("telugu");
  const [aiMood, setAiMood] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const autoplayedRef = useRef(false);
  const [history, setHistory] = useState<{ song: Song; count: number; last: number }[]>([]);

  const [panel, setPanel] = useState<null | "themes" | "queue" | "lyrics" | "liked" | "downloads" | "jam">(null);
  const [full, setFull] = useState(false);
  const [lyrics, setLyrics] = useState<{ synced: LyricLine[]; plain: string } | null | "loading">(null);
  const [hidden, setHidden] = useState(false);
  const [sound, setSound] = useState<SoundMode>("auto");
  const soundRef = useRef<SoundMode>("auto");
  soundRef.current = sound;
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const ctxRef = useRef<AudioContext | null>(null);
  const eqRef = useRef<EqNodes | null>(null);
  const normRef = useRef<GainNode | null>(null);
  const normMemRef = useRef<Record<string, number>>({});
  const toneRef = useRef<number[]>([0, 0, 0, 0, 0, 0]);
  const toneMemRef = useRef<Record<string, number[]>>({});
  const rawAnRef = useRef<AnalyserNode | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const [aiMixes, setAiMixes] = useState<{ text: string; at: number; songs: Song[] }[]>([]);
  const [sleepAt, setSleepAt] = useState<number | null>(null);
  const [now, setNow] = useState<Date | null>(null);
  const [view, setView] = useState<"home" | "dashboard">("home");
  const [installEvt, setInstallEvt] = useState<(Event & { prompt: () => Promise<void> }) | null>(null);
  const [canIosInstall, setCanIosInstall] = useState(false);
  const [canInstall, setCanInstall] = useState(false);
  const [installHint, setInstallHint] = useState(false);
  useEffect(() => {
    const standalone = window.matchMedia("(display-mode: standalone)").matches || (navigator as unknown as { standalone?: boolean }).standalone === true;
    if (standalone) return;
    setCanInstall(true);
    setCanIosInstall(/iphone|ipad|ipod/i.test(navigator.userAgent));
    const h = (e: Event) => { e.preventDefault(); setInstallEvt(e as Event & { prompt: () => Promise<void> }); };
    const done = () => { setInstallEvt(null); setCanIosInstall(false); setCanInstall(false); };
    window.addEventListener("beforeinstallprompt", h);
    window.addEventListener("appinstalled", done);
    return () => { window.removeEventListener("beforeinstallprompt", h); window.removeEventListener("appinstalled", done); };
  }, []);
  const install = async () => {
    if (installEvt) { await installEvt.prompt(); setInstallEvt(null); } else setInstallHint(true);
  };

  const current = idx >= 0 ? queue[idx] : undefined;

  // persist prefs
  useEffect(() => {
    try {
      const t = localStorage.getItem("vm-theme"); if (t) setTheme(t);
      const f = localStorage.getItem("vm-frame") as FrameKind | null; if (f && FRAMES.includes(f)) setFrame(f);
      const l = localStorage.getItem("vm-liked"); if (l) setLiked(JSON.parse(l) as Song[]);
    } catch { /* ignore */ }
  }, []);
  useEffect(() => { document.documentElement.dataset["theme"] = theme; localStorage.setItem("vm-theme", theme); }, [theme]);
  useEffect(() => { localStorage.setItem("vm-frame", frame); }, [frame]);
  useEffect(() => { localStorage.setItem("vm-liked", JSON.stringify(liked.slice(0, 100))); }, [liked]);

  // Keep the player alive across screen-off / app kills: restore song, queue and position instantly.
  const restorePosRef = useRef<number | null>(null);
  useEffect(() => {
    try {
      const s = JSON.parse(localStorage.getItem("vm-session") || "null") as { queue: Song[]; idx: number; pos: number } | null;
      if (s && Array.isArray(s.queue) && s.queue[s.idx]) {
        autoplayedRef.current = true;
        restorePosRef.current = s.pos || 0;
        setQueue(s.queue); setIdx(s.idx);
      }
    } catch { /* ignore */ }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (idx < 0 || !queue.length) return;
    const save = () => {
      try { localStorage.setItem("vm-session", JSON.stringify({ queue: queue.slice(0, 200), idx, pos: audioRef.current?.currentTime ?? 0 })); } catch { /* ignore */ }
    };
    save();
    const t = setInterval(save, 4000);
    const vis = () => { if (document.visibilityState === "hidden") save(); };
    document.addEventListener("visibilitychange", vis);
    window.addEventListener("pagehide", save);
    return () => { clearInterval(t); document.removeEventListener("visibilitychange", vis); window.removeEventListener("pagehide", save); };
  }, [queue, idx]);

  // mood refresh + home feed
  useEffect(() => {
    setMood(timeMood());
    const t = setInterval(() => setMood(timeMood()), 60000);
    return () => clearInterval(t);
  }, []);
  useEffect(() => {
        listDownloads<Song>().then((l) => setDownloads(l.sort((a, b) => b.savedAt - a.savedAt).map((d) => d.song))).catch(() => {});
    SINGERS.forEach((n) => artistImage(n).then((u) => u && setSingerImgs((m) => ({ ...m, [n]: u }))));
    const on = () => setOnline(navigator.onLine);
    on(); window.addEventListener("online", on); window.addEventListener("offline", on);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", on); };
  }, []);
  useEffect(() => {
    try { const l = localStorage.getItem("vm-lang"); if (l && ["telugu","hindi","tamil","malayalam","kannada","english"].includes(l)) setLang(l as typeof lang); } catch { /* ignore */ }
  }, []);
  useEffect(() => {
    setTrending([]);
    setOldies([]);
    localStorage.setItem("vm-lang", lang);
    searchSongs(`new ${lang} songs 2026`, 15).then(async (r) => {
      const fresh = r.filter((s) => Number(s.year) >= 2025);
      const list = fresh.length >= 5 ? fresh : r;
      setTrending(list);
      if (!autoplayedRef.current && list.length && !intro) {
        autoplayedRef.current = true;
        playAt(list, 0, false);
      }
    });
    searchSongs(`${lang} old hits`, 15).then(async (r) => setOldies(r.length ? r : await searchSongs(`90s ${lang} songs`, 15)));
  }, [lang]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    try { const h = localStorage.getItem("vm-history"); if (h) setHistory(JSON.parse(h) as typeof history); } catch { /* ignore */ }
  }, []);
  useEffect(() => {
    if (!current) return;
    setHistory((h) => {
      const prev = h.find((x) => x.song.id === current.id);
      const next = [{ song: current, count: (prev?.count ?? 0) + 1, last: Date.now() }, ...h.filter((x) => x.song.id !== current.id)].slice(0, 60);
      localStorage.setItem("vm-history", JSON.stringify(next));
      return next;
    });
  }, [current, playToken]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { searchSongs(mood.query, 18).then(async (r) => setHome(r.length ? r : await searchSongs(`${mood.key} songs`, 18))); }, [mood.key]); // eslint-disable-line react-hooks/exhaustive-deps

  // live search
  useEffect(() => {
    if (!query.trim()) { setResults([]); setAlbums([]); return; }
    setLoading(true);
    let stale = false;
    const t = setTimeout(async () => {
      const [s, a] = await Promise.all([searchSongs(query.trim()), searchAlbums(query.trim())]).catch(() => [[], []] as [Song[], Album[]]);
      if (stale) return; // a newer search replaced this one
      setResults(s); setAlbums(a); setLoading(false);
    }, 350);
    return () => { stale = true; clearTimeout(t); };
  }, [query]);

  // screen visibility (shows "playing in background" state)
  useEffect(() => {
    const h = () => setHidden(document.visibilityState === "hidden");
    document.addEventListener("visibilitychange", h);
    return () => document.removeEventListener("visibilitychange", h);
  }, []);

  // persisted extras + clock + sleep timer
  useEffect(() => {
    try {
      const s = localStorage.getItem("vm-sound") as SoundMode | null; if (s && SOUND_MODES.some((m) => m.id === s)) setSound(s);
      const m = localStorage.getItem("vm-ai-mixes"); if (m) setAiMixes(JSON.parse(m) as typeof aiMixes);
    } catch { /* ignore */ }
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(t);
  }, []);
  useEffect(() => {
    if (!sleepAt) return;
    const t = setInterval(() => { if (Date.now() >= sleepAt) { audioRef.current?.pause(); setSleepAt(null); } }, 5000);
    return () => clearInterval(t);
  }, [sleepAt]);

  // studio sound engine: EQ + gentle compressor for clear vocals and punchy beats
  const applyEq = useCallback((mode: SoundMode) => {
    const eq = eqRef.current; const ctx = ctxRef.current;
    if (!eq || !ctx) return;
    const cfg = SOUND_MODES.find((m) => m.id === mode) ?? SOUND_MODES[0]!;
    // per-song adaptive tone (warm for soft songs, tighter bass for beat-heavy) — never in Original
    const tone = mode === "flat" ? [0, 0, 0, 0, 0, 0] : toneRef.current;
    eq.filters.forEach((f, i) => f.gain.setTargetAtTime((cfg.g[i] ?? 0) + (tone[i] ?? 0), ctx.currentTime, 0.6));
    eq.pre.gain.setTargetAtTime(cfg.pre, ctx.currentTime, 0.08);
  }, []);
  useEffect(() => { localStorage.setItem("vm-sound", sound); applyEq(sound); }, [sound, applyEq]);
  const ensureAudio = useCallback(() => {
    const a = audioRef.current;
    if (!a) return;
    if (!ctxRef.current) {
      try {
        const W = window as unknown as { AudioContext?: typeof AudioContext; webkitAudioContext?: typeof AudioContext };
        const Ctx = W.AudioContext ?? W.webkitAudioContext;
        if (!Ctx) return;
        const ctx = new Ctx({ latencyHint: "playback" });
        const src = ctx.createMediaElementSource(a);
        const pre = ctx.createGain();
        const norm = ctx.createGain(); norm.gain.value = 1;
        const mk = (type: BiquadFilterType, freq: number, q = 1) => { const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q; return f; };
        // rumble filter keeps bass deep but clean (no distortion from inaudible sub energy)
        const rumble = mk("highpass", 24, 0.6);
        const filters = [mk("lowshelf", 70, 0.7), mk("peaking", 110, 1.0), mk("peaking", 280, 1.1), mk("peaking", 3200, 0.8), mk("peaking", 6800, 2.2), mk("highshelf", 10500, 0.7)];
        const comp = ctx.createDynamicsCompressor();
        // gentle glue: slower attack lets drum hits punch through, then holds the body steady
        comp.threshold.value = -20; comp.knee.value = 24; comp.ratio.value = 1.8; comp.attack.value = 0.02; comp.release.value = 0.35;
        const lim = ctx.createDynamicsCompressor();
        lim.threshold.value = -1.5; lim.knee.value = 1; lim.ratio.value = 20; lim.attack.value = 0.001; lim.release.value = 0.12;
        const an = ctx.createAnalyser(); an.fftSize = 2048; an.smoothingTimeConstant = 0.8;
        // raw-level meter: measures the song itself (before EQ/norm) for honest loudness + tone analysis
        const rawAn = ctx.createAnalyser(); rawAn.fftSize = 4096; rawAn.smoothingTimeConstant = 0.85;
        const mute = ctx.createGain(); mute.gain.value = 0;
        rumble.connect(rawAn).connect(mute).connect(ctx.destination); rawAnRef.current = rawAn;
        let node: AudioNode = src.connect(rumble).connect(norm).connect(pre);
        filters.forEach((f) => { node = node.connect(f); });
        const fade = ctx.createGain(); fade.gain.value = 1; fadeRef.current = fade;
        node.connect(comp).connect(lim).connect(fade).connect(an).connect(ctx.destination);
        ctxRef.current = ctx; eqRef.current = { filters, pre }; normRef.current = norm; analyserRef.current = an;
        setAnalyser(an);
        applyEq(soundRef.current);
      } catch { return; }
    }
    if (ctxRef.current?.state === "suspended") void ctxRef.current.resume();
  }, [applyEq]);

  const greetingTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const showGreeting = useCallback((message?: string) => {
    const m = timeMood(); setMood(m); setGreeting(message ?? m.greet);
    if (greetingTimerRef.current) clearTimeout(greetingTimerRef.current);
    greetingTimerRef.current = setTimeout(() => setGreeting(null), message ? 4200 : 3200);
  }, []);
  useEffect(() => () => { if (greetingTimerRef.current) clearTimeout(greetingTimerRef.current); }, []);

  const playAt = useCallback((list: Song[], i: number, open = true) => {
    ensureAudio();
    setQueue(list); setIdx(i); setPlayToken((t) => t + 1); showGreeting();
    if (open) setFull(true);
  }, [showGreeting, ensureAudio]);

  // load track
  useEffect(() => {
    const a = audioRef.current;
    if (!a || !current) return;
    let blobUrl = "";
    let cancelled = false;
    (async () => {
      const saved = await getDownload<Song>(current.id).catch(() => undefined);
      if (cancelled) return;
      if (saved) { blobUrl = URL.createObjectURL(saved.blob); a.src = blobUrl; }
      else { const src = audioOf(current); if (!src) return; a.src = src; }
      a.playbackRate = speedRef.current; a.defaultPlaybackRate = speedRef.current;
      const rp = restorePosRef.current;
      if (rp) { restorePosRef.current = null; a.addEventListener("loadedmetadata", () => { try { a.currentTime = rp; } catch { /* ignore */ } }, { once: true }); }
      const f = fadeRef.current, c = ctxRef.current;
      if (f && c) { f.gain.cancelScheduledValues(c.currentTime); f.gain.setValueAtTime(0.0001, c.currentTime); f.gain.exponentialRampToValueAtTime(1, c.currentTime + 1.6); }
      a.play().catch(() => setPlaying(false));
    })();
    setLyrics(null);
    suggestions(current.id).then(setRelated);
    // Lock screen / notification (works when screen is off)
    if ("mediaSession" in navigator) {
      const art = current.image ?? [];
      navigator.mediaSession.metadata = new MediaMetadata({
        title: decode(current.name),
        artist: `${artistOf(current)} • VIVEK'S MUSIX`,
        album: `${decode(current.album?.name)} — powered by VIVEK`,
        artwork: art.map((i) => ({ src: i.url, sizes: i.quality, type: "image/jpeg" })),
      });
    }
    return () => { cancelled = true; if (blobUrl) setTimeout(() => URL.revokeObjectURL(blobUrl), 1000); };
  }, [current, playToken]); // eslint-disable-line react-hooks/exhaustive-deps

  // lyrics when panel open
  useEffect(() => {
    if (panel !== "lyrics" || !current || lyrics) return;
    setLyrics("loading");
    fetchLyrics(current).then((l) => setLyrics(l));
  }, [panel, current, lyrics]);

  const nextBusy = useRef(false);
  const streamErrs = useRef(0);
  const next = useCallback(async () => {
    if (!queue.length || nextBusy.current) return;
    nextBusy.current = true;
    try { await nextInner(); } finally { nextBusy.current = false; }
    async function nextInner() {
    const go = (i: number) => { setIdx(i); setPlayToken((t) => t + 1); };
    if (shuffle && queue.length > 1) { let j = idx; while (j === idx) j = Math.floor(Math.random() * queue.length); go(j); return; }
    if (idx < queue.length - 1) { go(idx + 1); return; }
    if (repeat === "all") { go(0); return; }
    // end of the list: keep the music going with similar songs
    const seen = new Set(queue.map((q) => q.id));
    const base = queue[idx];
    let more = related.filter((r) => !seen.has(r.id));
    if (!more.length && base) more = (await suggestions(base.id).catch(() => [] as Song[])).filter((r) => !seen.has(r.id));
    if (!more.length && base) more = (await searchSongs(`${artistOf(base)} songs`, 20).catch(() => [] as Song[])).filter((r) => !seen.has(r.id));
    if (more.length) { setQueue((q) => [...q, ...more]); go(idx + 1); }
    else if (queue.length > 1) go(0);
    }
  }, [queue, idx, shuffle, repeat, related]);
  const prev = useCallback(() => {
    const a = audioRef.current;
    if (a && a.currentTime > 3) { a.currentTime = 0; return; }
    if (idx > 0) setIdx(idx - 1);
  }, [idx]);
  const toggle = useCallback(() => {
    const a = audioRef.current;
    if (!a || !current) return;
    ensureAudio();
    if (a.paused) a.play().catch(() => {}); else a.pause();
  }, [current, ensureAudio]);

  // ---- Jam: listen together ----
  const remoteUntil = useRef(0);
  const jamSeek = useRef<number | null>(null);
  const jamPaused = useRef(false);
  const [jamName, setJamName] = useState("");
  const [jamInput, setJamInput] = useState("");
  const [jamCopied, setJamCopied] = useState(false);
  useEffect(() => { setJamName(localStorage.getItem("vm-name") ?? ""); }, []);
  const lagOf = (at: number) => { const l = (Date.now() - at) / 1000; return l > 0 && l < 3 ? l : 0; };
  const jam = useJam((m: JamMsg) => {
    const a = audioRef.current;
    if (m.t === "sync") { if (current && a) jam.send({ t: "play", song: current, pos: a.currentTime, playing: !a.paused, at: Date.now() }); return; }
    remoteUntil.current = Date.now() + 1500;
    if (m.t === "play") {
      const song = m.song as Song;
      const pos = m.pos + (m.playing ? lagOf(m.at) : 0);
      if (current?.id === song.id && a) { a.currentTime = pos; if (m.playing) void a.play().catch(() => {}); else a.pause(); return; }
      jamSeek.current = pos; jamPaused.current = !m.playing;
      const qi = queue.findIndex((q) => q.id === song.id);
      if (qi >= 0) { setIdx(qi); setPlayToken((t) => t + 1); } else playAt([song], 0, false);
      return;
    }
    if (!a) return;
    if (m.t === "pause") { a.currentTime = m.pos; a.pause(); }
    else if (m.t === "resume") { a.currentTime = m.pos + lagOf(m.at); void a.play().catch(() => {}); }
    else if (m.t === "seek") a.currentTime = m.pos + (a.paused ? 0 : lagOf(m.at));
  });
  const jamLive = jam.status === "live";
  const fromMe = () => jamLive && Date.now() > remoteUntil.current;
  useEffect(() => {
    if (current && fromMe()) jam.send({ t: "play", song: current, pos: 0, playing: true, at: Date.now() });
  }, [current?.id, playToken]); // eslint-disable-line react-hooks/exhaustive-deps

  // per-song auto loudness + adaptive tone, measured on the raw song (not the processed output)
  useEffect(() => {
    const id = current?.id; if (!id) return;
    let sum = 0, n = 0, bassAcc = 0, midAcc = 0, hiAcc = 0, tn = 0;
    {
      const ctx = ctxRef.current, norm = normRef.current; const g = normMemRef.current[id] ?? 0.95;
      if (ctx && norm) norm.gain.setTargetAtTime(g, ctx.currentTime, 0.3);
      toneRef.current = toneMemRef.current[id] ?? [0, 0, 0, 0, 0, 0]; applyEq(soundRef.current);
    }
    const buf = new Float32Array(4096); let fbuf = new Float32Array(2048);
    const t = setInterval(() => {
      const ctx = ctxRef.current, norm = normRef.current, a = audioRef.current, an = rawAnRef.current;
      if (!ctx || !norm || !a || a.paused || !an) return;
      const b = buf.subarray(0, an.fftSize); an.getFloatTimeDomainData(b);
      let s = 0; for (let i = 0; i < b.length; i++) s += b[i]! * b[i]!;
      const rms = Math.sqrt(s / b.length); if (rms < 0.005) return; // skip silence/intros
      sum += rms; n++;
      // spectrum balance: bass (<150Hz) vs body/vocals (300–3k) vs highs (5k–12k)
      if (fbuf.length !== an.frequencyBinCount) fbuf = new Float32Array(an.frequencyBinCount);
      an.getFloatFrequencyData(fbuf);
      const hz = ctx.sampleRate / an.fftSize;
      const band = (lo: number, hi: number) => { let e = 0, c = 0; for (let i = Math.floor(lo / hz); i <= Math.ceil(hi / hz) && i < fbuf.length; i++) { e += Math.pow(10, fbuf[i]! / 10); c++; } return c ? e / c : 0; };
      bassAcc += band(40, 150); midAcc += band(300, 3000); hiAcc += band(5000, 12000); tn++;
      if (n >= 6) {
        const avg = sum / n;
        // gain from the raw level: loud masters cut, quiet ones lifted only a little
        const target = Math.min(1.25, Math.max(0.62, 0.24 / avg));
        const cur = norm.gain.value || 1;
        const smooth = cur + (target - cur) * 0.5;
        norm.gain.setTargetAtTime(smooth, ctx.currentTime, 2.5);
        normMemRef.current[id] = smooth;
        sum = 0; n = 0;
      }
      if (tn >= 16) {
        const bassDb = 10 * Math.log10((bassAcc + 1e-12) / (midAcc + 1e-12));
        const hiDb = 10 * Math.log10((hiAcc + 1e-12) / (midAcc + 1e-12));
        const clamp = (v: number, m: number) => Math.max(-m, Math.min(m, v));
        // beat-heavy mixes: tighter sub, a touch more punch; soft/love songs: warmer low end
        const heavy = clamp((bassDb - 16) / 5, 0.8);
        const bright = clamp((hiDb + 22) / 6, 1.2);
        const tone = [-heavy, heavy > 0 ? 0.4 * heavy : 0, heavy < 0 ? 0.3 * heavy : 0, 0, -Math.max(0, bright), -0.5 * bright];
        const prev = toneRef.current;
        toneRef.current = tone.map((v, i) => (prev[i] ?? 0) + (v - (prev[i] ?? 0)) * 0.5);
        toneMemRef.current[id] = toneRef.current;
        applyEq(soundRef.current);
        bassAcc = midAcc = hiAcc = 0; tn = 0;
      }
    }, 500);
    return () => clearInterval(t);
  }, [current?.id, applyEq]);

  useEffect(() => {
    if (!("mediaSession" in navigator)) return;
    const ms = navigator.mediaSession;
    ms.setActionHandler("play", () => audioRef.current?.play());
    ms.setActionHandler("pause", () => audioRef.current?.pause());
    ms.setActionHandler("nexttrack", next);
    ms.setActionHandler("previoustrack", prev);
    ms.setActionHandler("seekto", (d) => { if (audioRef.current && d.seekTime != null) audioRef.current.currentTime = d.seekTime; });
    ms.playbackState = playing ? "playing" : "paused";
  }, [next, prev, playing]);

  // Android APK: native foreground media service mirrors the same single audio player
  useEffect(() => {
    void nativeHandlers({
      play: () => { void audioRef.current?.play(); },
      pause: () => audioRef.current?.pause(),
      next: () => { void next(); },
      prev,
      seek: (t) => { if (audioRef.current) audioRef.current.currentTime = t; },
    });
  }, [next, prev]);
  useEffect(() => { const a = audioRef.current; if (a && a.duration) void nativePosition(a.duration, a.currentTime); void nativeState(playing); }, [playing]);
  useEffect(() => {
    if (!current) return;
    void nativeMeta({
      title: decode(current.name),
      artist: `${artistOf(current)} • VIVEK'S MUSIX`,
      album: decode(current.album?.name),
      artwork: (current.image ?? []).map((i) => ({ src: i.url, sizes: i.quality, type: "image/jpeg" })),
    });
  }, [current]);
  useEffect(() => { if (dur && Math.floor(time) % 5 === 0) void nativePosition(dur, time); }, [Math.floor(time), dur]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!("mediaSession" in navigator) || !dur) return;
    try { navigator.mediaSession.setPositionState({ duration: dur, position: Math.min(time, dur), playbackRate: 1 }); } catch { /* ignore */ }
  }, [time, dur]);

  useEffect(() => { if (audioRef.current) { audioRef.current.volume = volume; audioRef.current.muted = muted; } }, [volume, muted]);

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).tagName === "INPUT") return;
      if (e.code === "Space") { e.preventDefault(); toggle(); }
      if (e.code === "ArrowRight" && e.shiftKey) next();
      if (e.code === "ArrowLeft" && e.shiftKey) prev();
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [toggle, next, prev]);

  const isLiked = current ? liked.some((l) => l.id === current.id) : false;
  const toggleLike = (s: Song) => setLiked((l) => (l.some((x) => x.id === s.id) ? l.filter((x) => x.id !== s.id) : [s, ...l]));

  const activeLine = useMemo(() => {
    if (!lyrics || lyrics === "loading" || !lyrics.synced.length) return -1;
    let i = -1;
    lyrics.synced.forEach((l, j) => { if (l.t <= time) i = j; });
    return i;
  }, [lyrics, time]);
  const lyricRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    lyricRef.current?.querySelector(`[data-line="${activeLine}"]`)?.scrollIntoView({ block: "center", behavior: "smooth" });
  }, [activeLine]);

  const MoodIcon = mood.Icon;
  const onHome = !query.trim() && view === "home";
  const listToShow = query.trim() ? results : home;
  // Daily Mix: liked + most-played songs, shuffled the same way all day, new order tomorrow
  const dailyMix = useMemo(() => {
    const seen = new Set<string>(); const pool: Song[] = [];
    [...liked, ...[...history].sort((a, b) => b.count - a.count).map((h) => h.song)].forEach((s) => { if (!seen.has(s.id)) { seen.add(s.id); pool.push(s); } });
    const day = now ? Math.floor(now.getTime() / 86400000) : 0;
    const score = (id: string) => { let h = day; for (const c of id) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h; };
    return pool.sort((a, b) => score(a.id) - score(b.id)).slice(0, 30);
  }, [liked, history, now?.toDateString()]); // eslint-disable-line react-hooks/exhaustive-deps

  const isDownloaded = (id: string) => downloads.some((d) => d.id === id);
  const toggleDownload = async (s: Song) => {
    if (isDownloaded(s.id)) {
      await removeDownload(s.id); setDownloads((d) => d.filter((x) => x.id !== s.id)); return;
    }
    if (dlProgress[s.id] != null) return;
    const url = audioOf(s); if (!url) return;
    setDlProgress((p) => ({ ...p, [s.id]: 0 }));
    try {
      const blob = await fetchWithProgress(url, (v) => setDlProgress((p) => ({ ...p, [s.id]: v })));
      await saveDownload({ id: s.id, song: s, blob, savedAt: Date.now() });
      setDownloads((d) => [s, ...d.filter((x) => x.id !== s.id)]);
    } catch { /* ignore */ }
    setDlProgress((p) => { const n = { ...p }; delete n[s.id]; return n; });
  };
  const DlBtn = ({ s, size = 18 }: { s: Song; size?: number }) => {
    const prog = dlProgress[s.id];
    const done = isDownloaded(s.id);
    return (
      <button aria-label={done ? "Remove download" : "Download"} title={done ? "Downloaded — tap to remove" : "Download for offline"} onClick={(e) => { e.stopPropagation(); void toggleDownload(s); }}
        className="relative flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-muted-foreground transition hover:bg-muted hover:text-foreground">
        {prog != null ? (
          <svg viewBox="0 0 36 36" className="h-7 w-7 -rotate-90"><circle cx="18" cy="18" r="15" fill="none" stroke="var(--muted)" strokeWidth="3" /><circle cx="18" cy="18" r="15" fill="none" stroke="var(--primary)" strokeWidth="3" strokeDasharray={`${prog * 94} 94`} strokeLinecap="round" /></svg>
        ) : done ? <CheckCircle2 size={size} className="text-primary" /> : <Download size={size} />}
      </button>
    );
  };
  const openBrowse = async (title: string, q: string, autoplay = true, fallback?: string) => {
    setView("home");
    setBrowse({ title, songs: [], loading: true });
    let songs = await searchSongs(q, 30);
    if (!songs.length && fallback) songs = await searchSongs(fallback, 30);
    setBrowse({ title, songs, loading: false });
    if (autoplay && songs.length) playAt(songs, 0);
    setTimeout(() => document.getElementById("vm-browse")?.scrollIntoView({ behavior: "smooth", block: "start" }), 120);
  };
  const showList = (title: string, songs: Song[]) => {
    setView("home");
    setBrowse({ title, songs, loading: false });
    setTimeout(() => document.getElementById("vm-browse")?.scrollIntoView({ behavior: "smooth", block: "start" }), 120);
  };

  const openSinger = async (name: string) => {
    setPlaylist({ title: `${name} hits`, img: singerImgs[name], songs: [], loading: true });
    let songs = await searchSongs(`${name} songs`, 40);
    if (!songs.length) songs = await searchSongs(name, 40);
    setPlaylist({ title: `${name} hits`, img: singerImgs[name], songs, loading: false });
    if (songs.length) playAt(songs, 0, false);
  };

  // Discover pick → its own page with songs from every major language (not only one)
  const discoverAutoRef = useRef(false); // only the very first Discover pick auto-plays
  const openDiscover = async (title: string, q: (l: string) => string) => {
    setPlaylist({ title, songs: [], loading: true });
    const langs = [lang, ...["telugu", "hindi", "tamil", "english", "malayalam", "kannada", "punjabi", "bengali", "marathi"].filter((l) => l !== lang)];
    const lists = await Promise.all(langs.map((l) => searchSongs(q(l), 15).catch(() => [] as Song[])));
    const seen = new Set<string>(); const songs: Song[] = [];
    for (let i = 0; i < 15; i++) for (const list of lists) { const s = list[i]; if (s && !seen.has(s.id)) { seen.add(s.id); songs.push(s); } }
    setPlaylist({ title, songs, loading: false });
    if (songs.length && !discoverAutoRef.current) { discoverAutoRef.current = true; playAt(songs, 0, false); }
  };

  // smooth fade out in the last seconds of a song (the next one fades in)
  useEffect(() => {
    const a = audioRef.current; if (!a) return;
    let fading = false;
    const onT = () => {
      const f = fadeRef.current, c = ctxRef.current; if (!f || !c || !a.duration) return;
      const left = (a.duration - a.currentTime) / (a.playbackRate || 1);
      if (left < 2.5 && left > 0.1 && !fading && repeat !== "one") { fading = true; f.gain.cancelScheduledValues(c.currentTime); f.gain.setValueAtTime(f.gain.value, c.currentTime); f.gain.linearRampToValueAtTime(0.0001, c.currentTime + left); }
      else if (left >= 2.5 && fading) { fading = false; f.gain.cancelScheduledValues(c.currentTime); f.gain.setTargetAtTime(1, c.currentTime, 0.2); }
    };
    a.addEventListener("timeupdate", onT);
    return () => a.removeEventListener("timeupdate", onT);
  }, [repeat]);
  useEffect(() => {
    const a = audioRef.current; if (!a) return;
    let last = a.currentTime; let id = current?.id;
    const onTime = () => {
      const raw = a.currentTime - last; last = a.currentTime;
      if (a.paused || raw <= 0 || raw > 4 || !current) return;
      const d = raw / (a.playbackRate || 1); // real clock time, even at 1.5x / 2x
      const cur = listenRef.current;
      listenRef.current = { total: cur.total + d, songs: { ...cur.songs, [current.id]: (cur.songs[current.id] ?? 0) + d } };
    };
    const onSeek = () => { last = a.currentTime; };
    const flush = setInterval(() => { setListen(listenRef.current); try { localStorage.setItem("vm-listen", JSON.stringify(listenRef.current)); } catch { /* ignore */ } }, 5000);
    a.addEventListener("timeupdate", onTime); a.addEventListener("seeking", onSeek); a.addEventListener("loadstart", onSeek);
    void id;
    return () => { a.removeEventListener("timeupdate", onTime); a.removeEventListener("seeking", onSeek); a.removeEventListener("loadstart", onSeek); clearInterval(flush); setListen(listenRef.current); try { localStorage.setItem("vm-listen", JSON.stringify(listenRef.current)); } catch { /* ignore */ } };
  }, [current]); // eslint-disable-line react-hooks/exhaustive-deps

  const stats = useMemo(() => {
    const plays = history.reduce((a, h) => a + h.count, 0);
    const mins = Math.floor(listen.total / 60);
    const ac: Record<string, number> = {};
    history.forEach((h) => { const n = h.song.artists?.primary?.[0]?.name; if (n) ac[n] = (ac[n] ?? 0) + h.count; });
    const topArtists = Object.entries(ac).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([n]) => decode(n));
    return { plays, mins, topArtists };
  }, [history, listen.total]);

  const buildAiQueue = async (preset?: string) => {
    const text = (preset ?? aiMood).trim();
    if (!text || aiLoading) return;
    if (preset) setAiMood(preset);
    setAiLoading(true);
    setAiError(null);
    try {
      const context = `Time of day: ${timeMood().greet}. Preferred language: ${lang}. Artists this listener plays most: ${stats.topArtists.join(", ") || "unknown"}. Their recent AI mix requests: ${aiMixes.slice(0, 3).map((m) => m.text).join("; ") || "none"}.`;
      // In the standalone APK there is no app server, so fall back to plain mood search.
      const queries: string[] = await getMoodQueries({ data: { mood: text, context } }).catch(() => [] as string[]);
      const batches = await Promise.all([`${text} ${lang}`.includes(lang) && !text.toLowerCase().includes(lang) ? `${lang} ${text}` : text, ...queries].map((q, k) => searchSongs(q, k === 0 ? 12 : 8)));
      const seen = new Set<string>();
      const songs = batches.flat().filter((s) => (seen.has(s.id) ? false : (seen.add(s.id), true)));
      if (!songs.length) throw new Error("empty");
      setBrowse({ title: `Vibe · ${text}`, songs, loading: false });
      playAt(songs, 0);
      const mix = { text, at: Date.now(), songs: songs.slice(0, 20) };
      setAiMixes((m) => {
        const n = [mix, ...m.filter((x) => x.text.toLowerCase() !== text.toLowerCase())].slice(0, 8);
        try { localStorage.setItem("vm-ai-mixes", JSON.stringify(n)); } catch { /* ignore */ }
        return n;
      });
      setTimeout(() => document.getElementById("vm-browse")?.scrollIntoView({ behavior: "smooth", block: "start" }), 120);
    } catch {
      setAiError("Vibe Engine failed right now — please try again in a moment.");
    }
    setAiLoading(false);
  };

  const SongRow = ({ s, list, i }: { s: Song; list: Song[]; i: number }) => {
    const active = current?.id === s.id;
    return (
      <div className="vm-row flex items-center gap-1"><button onClick={() => playAt(list, i)} className={`group flex min-w-0 flex-1 items-center gap-3 rounded-xl p-2 text-left transition hover:bg-muted ${active ? "bg-muted" : ""}`}>
        <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded-lg">
          <img src={imgOf(s, false)} alt="" className="h-full w-full object-cover" loading="lazy" />
          <div className={`absolute inset-0 flex items-center justify-center bg-background/60 ${active ? "opacity-100" : "opacity-0 group-hover:opacity-100"}`}>
            {active && playing ? <Bars /> : <Play size={18} className="fill-foreground text-foreground" />}
          </div>
        </div>
        <div className="min-w-0 flex-1">
          <p className={`truncate font-medium ${active ? "text-primary" : "text-foreground"}`}>{decode(s.name)}</p>
          <p className="truncate text-sm text-muted-foreground">{artistOf(s)}</p>
        </div>
        <span className="text-xs tabular-nums text-muted-foreground">{fmt(s.duration ?? 0)}</span>
      </button>
      <button aria-label="Like" onClick={() => toggleLike(s)} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-muted-foreground transition hover:bg-muted"><Heart size={16} className={liked.some((l) => l.id === s.id) ? "fill-primary text-primary" : ""} /></button>
      {DlBtn({ s })}</div>
    );
  };

  return (
    <div className="vm-app-root relative isolate min-h-screen overflow-x-clip bg-background pb-52 text-foreground transition-colors duration-500 sm:pb-40">
      <div aria-hidden className="vm-ambient"><span /><span /><span /><i className="vm-grain" /><ClientOnly fallback={null}>{current && <img key={current.id} src={imgOf(current, false)} alt="" className="vm-art-glow" />}</ClientOnly></div>
      {intro && <Intro onDone={() => { setIntro(false); showGreeting("Welcome to VIVEK'S MUSIX"); }} />}
      <audio
        ref={audioRef}
        preload="auto"
        crossOrigin="anonymous"
        onPlay={(e) => { setPlaying(true); if (ctxRef.current?.state === "suspended") void ctxRef.current.resume(); if (fromMe() && e.currentTarget.currentTime > 1) jam.send({ t: "resume", pos: e.currentTarget.currentTime, at: Date.now() }); }}
        onPause={(e) => { setPlaying(false); const a = e.currentTarget; if (fromMe() && !a.ended && a.duration - a.currentTime > 1) jam.send({ t: "pause", pos: a.currentTime }); }}
        onSeeked={(e) => { if (fromMe()) jam.send({ t: "seek", pos: e.currentTarget.currentTime, at: Date.now() }); }}
        onWaiting={() => setBuffering(true)}
        onPlaying={() => { setBuffering(false); streamErrs.current = 0; }}
        onError={(e) => {
          // broken/unavailable stream: skip ahead a few times, never loop forever
          setBuffering(false); setPlaying(false);
          const err = e.currentTarget.error; if (!err || !current) return;
          console.warn("[VIVEK] stream failed", err.code, current.id);
          if (streamErrs.current >= 3 || (jamLive && !jam.isLeader)) return;
          streamErrs.current++;
          setTimeout(() => void next(), 1200);
        }}
        onTimeUpdate={(e) => { if (document.hidden) return; const t = Math.floor(e.currentTarget.currentTime); setTime((p) => (Math.floor(p) === t ? p : t)); }}
        onLoadedMetadata={(e) => {
          setDur(e.currentTarget.duration);
          if (jamSeek.current != null) { remoteUntil.current = Date.now() + 1500; e.currentTarget.currentTime = jamSeek.current; jamSeek.current = null; if (jamPaused.current) e.currentTarget.pause(); }
        }}
        onEnded={() => {
          if (repeat === "one" && audioRef.current) { audioRef.current.currentTime = 0; void audioRef.current.play().catch(() => {}); return; }
          if (jamLive && !jam.isLeader) return; // the Jam host moves everyone to the next song
          void next();
        }}
      />

      {/* ambient glow */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        {current && <img src={imgOf(current, false)} alt="" decoding="async" className="absolute inset-0 h-full w-full scale-125 object-cover opacity-20 blur-2xl" />}
        <div className="absolute -left-40 -top-40 h-96 w-96 rounded-full bg-primary/15 blur-3xl" />
        <div className="absolute -right-40 top-1/3 h-96 w-96 rounded-full bg-accent/15 blur-3xl" />
      </div>

      {installHint && (
        <div className="fixed inset-0 z-[70] flex items-end justify-center bg-background/70 p-4 backdrop-blur-sm sm:items-center" onClick={() => setInstallHint(false)}>
          <div className="w-full max-w-sm rounded-3xl border border-border bg-card p-6 text-center shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <MonitorDown className="mx-auto text-primary" size={32} />
            <h3 className="font-display mt-3 text-xl font-bold">Install VIVEK'S MUSIX</h3>
            {canIosInstall
              ? <p className="mt-2 text-sm text-muted-foreground">Tap the <b>Share</b> button in Safari, then choose <b>Add to Home Screen</b>.</p>
              : <p className="mt-2 text-sm text-muted-foreground">Open the browser menu <b>(⋮)</b> and choose <b>Install app</b> or <b>Add to Home screen</b>. On a laptop, click the install icon in the address bar.</p>}
            <button onClick={() => setInstallHint(false)} className="mt-5 w-full rounded-full bg-primary py-3 text-sm font-bold text-primary-foreground">Got it</button>
          </div>
        </div>
      )}

      <aside className="vm-sidebar fixed bottom-[6.5rem] left-4 top-4 z-30 hidden w-56 flex-col rounded-2xl p-3 lg:flex 2xl:left-5 2xl:w-60">
        <div className="border-b border-border/70 px-2 pb-5 pt-2"><Logo compact /></div>
        <nav aria-label="Main navigation" className="mt-4 space-y-1">
          {[
            { label: "Home", Icon: HomeIcon, active: view === "home" && !panel, action: () => { setPanel(null); setQuery(""); setView("home"); window.scrollTo({ top: 0 }); } },
            { label: "Dashboard", Icon: LayoutDashboard, active: view === "dashboard" && !panel, action: () => { setPanel(null); setQuery(""); setView("dashboard"); window.scrollTo({ top: 0 }); } },
            { label: "Liked songs", Icon: Heart, active: panel === "liked", action: () => setPanel("liked") },
            { label: "Downloads", Icon: Download, active: panel === "downloads", action: () => setPanel("downloads") },
            { label: "Queue", Icon: ListMusic, active: panel === "queue", action: () => setPanel("queue") },
          ].map(({ label, Icon, active, action }) => (
            <button key={label} onClick={action} className={`vm-sidebar-link flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium transition ${active ? "vm-sidebar-link-on" : "text-muted-foreground"}`}>
              <Icon size={17} strokeWidth={1.8} /><span>{label}</span>
            </button>
          ))}
        </nav>
        <div className="mt-auto border-t border-border/70 pt-3">
          <p className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Recently played</p>
          <div className="space-y-1">
            {history.slice(0, 3).map(({ song }) => (
              <button key={song.id} onClick={() => playAt(history.map((entry) => entry.song), history.findIndex((entry) => entry.song.id === song.id))} className="flex w-full min-w-0 items-center gap-2 rounded-lg p-2 text-left transition hover:bg-foreground/5">
                <img src={imgOf(song, false)} alt="" className="h-8 w-8 shrink-0 rounded-md object-cover" loading="lazy" />
                <span className="min-w-0 truncate text-xs font-medium">{decode(song.name)}</span>
              </button>
            ))}
            {history.length === 0 && <p className="px-3 py-2 text-xs text-muted-foreground">Your recent songs appear here.</p>}
          </div>
        </div>
        <button onClick={() => setPanel(panel === "themes" ? null : "themes")} className="vm-sidebar-link mt-3 flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium text-muted-foreground transition">
          <Palette size={17} strokeWidth={1.8} /> Appearance
        </button>
      </aside>

      <div className="relative mx-auto max-w-6xl px-4 sm:px-6 lg:mx-0 lg:ml-64 lg:mr-6 lg:max-w-none lg:px-8 2xl:ml-72 2xl:mr-10 2xl:px-12">
        {/* header */}
        <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 py-4 sm:flex sm:justify-between sm:py-5">
          <div className="lg:hidden"><Logo /></div>
          <div className="hidden min-w-0 lg:block">
            <p className="font-display truncate text-lg font-bold">{query.trim() ? "Search results" : view === "dashboard" ? "Your dashboard" : "Discover"}</p>
          </div>
          <div className="flex shrink-0 items-center gap-0.5 sm:gap-1">
            {canInstall && (
              <button onClick={() => void install()} className="mr-1 flex items-center gap-1.5 rounded-full bg-primary px-2.5 py-2 text-xs font-bold text-primary-foreground shadow-lg transition hover:scale-105"><MonitorDown size={16} /> <span className="hidden sm:inline">Install</span></button>
            )}
            <IconBtn label="Home" onClick={() => { setView("home"); setQuery(""); window.scrollTo({ top: 0 }); }} className={`hidden lg:flex ${view === "home" ? "text-primary" : ""}`}><HomeIcon size={20} /></IconBtn>
            <IconBtn label="Dashboard" onClick={() => { setView("dashboard"); setQuery(""); window.scrollTo({ top: 0 }); }} className={`hidden lg:flex ${view === "dashboard" ? "text-primary" : ""}`}><LayoutDashboard size={20} /></IconBtn>
            <IconBtn label="Liked songs" onClick={() => setPanel("liked")} className="hidden lg:flex"><Heart size={20} /></IconBtn>
            <IconBtn label="Downloads" onClick={() => setPanel("downloads")} className="hidden lg:flex"><Download size={20} /></IconBtn>
            <IconBtn label="Jam" onClick={() => setPanel(panel === "jam" ? null : "jam")} className={jamLive ? "text-primary" : ""}><Users size={20} /></IconBtn>
            <IconBtn label="Themes" onClick={() => setPanel(panel === "themes" ? null : "themes")}><Palette size={20} /></IconBtn>
          </div>
        </header>

        {/* Search stays at the top while browsing, just below the brand bar. */}
        <div className="sticky top-2 z-30 mb-5">
          <div className="vm-top-search flex items-center gap-3 rounded-xl px-4 py-3 backdrop-blur-xl focus-within:ring-1 focus-within:ring-primary/60">
            <Search size={19} className="shrink-0 text-muted-foreground" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search songs, artists, albums…" className="w-full bg-transparent text-base outline-none placeholder:text-muted-foreground" />
            {loading ? <Loader2 className="animate-spin text-primary" size={18} /> : query && <button onClick={() => setQuery("")} aria-label="Clear search"><X size={18} /></button>}
          </div>
        </div>

        {/* Results appear right under the search bar — no scrolling needed */}
        {query.trim() && (
          <section className="vm-glass-strong vm-greet mb-6 rounded-3xl p-3 sm:p-4">
            <div className="mb-2 flex items-center justify-between px-1">
              <h2 className="font-display text-lg font-bold">Top results</h2>
              {loading && <span className="text-xs text-muted-foreground">Searching…</span>}
            </div>
            {!loading && results.length === 0 && <p className="px-1 py-4 text-sm text-muted-foreground">No songs found. Try another search.</p>}
            {loading && results.length === 0 && (
              <div className="space-y-2">{[0, 1, 2, 3].map((i) => <div key={i} className="h-14 animate-pulse rounded-xl bg-muted/40" />)}</div>
            )}
            <div className="space-y-1">
              {results.map((s, i) => <Fragment key={s.id + i}>{SongRow({ s: s, list: results, i: i })}</Fragment>)}
            </div>
          </section>
        )}

        {/* Discover something new + daily library mix */}
        {!query.trim() && view === "home" && (
          <section className="mb-6">
            <h2 className="font-display mb-3 text-lg font-bold">Discover something new</h2>
            <div className="scrollbar-none -mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
              {DISCOVER.map(([d, q]) => (
                <button key={d} onClick={() => openDiscover(d, q)} className="vm-chip shrink-0">{d}</button>
              ))}
            </div>
            {dailyMix.length > 0 && (
              <button onClick={() => playAt(dailyMix, 0)} className="vm-glass mt-4 flex w-full items-center gap-4 rounded-2xl p-3 text-left transition active:scale-[0.99]">
                <div className="grid h-16 w-16 shrink-0 grid-cols-2 overflow-hidden rounded-xl">
                  {dailyMix.slice(0, 4).map((s) => <img key={s.id} src={imgOf(s, false)} alt="" className="h-full w-full object-cover" />)}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-primary">Your library · today</p>
                  <p className="font-display truncate text-base font-bold">Daily Mix</p>
                  <p className="truncate text-xs text-muted-foreground">{dailyMix.length} {dailyMix.length === 1 ? "song" : "songs"} from your likes & listening</p>
                </div>
                <span className="vm-playglow grid h-11 w-11 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground"><Play size={18} className="ml-0.5 fill-current" /></span>
              </button>
            )}
          </section>
        )}

        {greeting && (
          <div className="vm-greet vm-glass-strong mb-4 flex w-fit max-w-full items-center gap-2.5 rounded-2xl border border-primary/40 py-2 pl-2 pr-4" style={{ boxShadow: "0 16px 40px -20px color-mix(in oklab, var(--primary) 65%, transparent)" }}>
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-primary to-accent text-primary-foreground"><MoodIcon size={18} /></span>
            {greeting === "Welcome to VIVEK'S MUSIX" ? (
              <span className="min-w-0 leading-tight">
                <span className="block text-[10px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">Welcome to</span>
                <span className="font-display block truncate text-sm font-extrabold text-primary sm:text-base">VIVEK'S MUSIX</span>
              </span>
            ) : (
              <span className="min-w-0 leading-tight">
                <span className="font-display block truncate bg-gradient-to-r from-primary to-accent bg-clip-text text-base font-extrabold text-transparent">{greeting}</span>
                <span className="block truncate text-xs text-muted-foreground">{mood.line}</span>
              </span>
            )}
          </div>
        )}

        {/* cinematic hero */}
        {(() => { const f = trending[0] ?? home[0]; return (
        <section className={`vm-cine relative mb-6 overflow-hidden rounded-[2rem] ${view === "home" && !query.trim() ? "" : "hidden"}`}>
          {f && <img src={imgOf(f, false)} alt="" aria-hidden decoding="async" className="pointer-events-none absolute inset-0 h-full w-full scale-125 object-cover opacity-55 blur-2xl" />}
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-background via-background/80 to-background/20" />
          <div className="vm-cine-content relative grid items-center gap-6 p-6 sm:grid-cols-[minmax(0,1fr)_auto] sm:p-10">
            <div className="min-w-0">
              <p className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.25em] text-muted-foreground sm:text-[11px]">
                <LiveDot /> {now ? `${now.toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long" })} · ${now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` : "Live"}
              </p>
              <h2 className="font-display mt-3 pb-1 text-5xl font-extrabold leading-[0.95] sm:text-6xl lg:text-7xl">{mood.greet}</h2>
              <p className="mt-2 max-w-md text-sm text-muted-foreground sm:text-base">{mood.line}</p>
              {f && <button onClick={() => playAt(trending.length ? trending : home, 0)} className="group mt-6 flex max-w-full items-center gap-3 text-left">
                <span className="vm-playglow grid h-14 w-14 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground transition duration-300 group-hover:scale-105 group-active:scale-95"><Play size={22} className="ml-0.5 fill-current" /></span>
                <span className="min-w-0"><span className="block text-[10px] font-semibold uppercase tracking-[0.25em] text-primary">Featured · #1 trending</span><span className="block truncate font-semibold">{decode(f.name)}</span><span className="block truncate text-xs text-muted-foreground">{artistOf(f)}</span></span>
              </button>}
              <div className="mt-5 flex flex-wrap gap-2">
                <button onClick={() => { if (home.length) playAt(home, 0); }} className="vm-chip flex items-center gap-2"><MoodIcon size={14} /> Play {mood.key} mix</button>
              </div>
            </div>
            {f && <button onClick={() => playAt(trending.length ? trending : home, 0)} aria-label="Play featured" className="vm-feature relative mx-auto mt-1 block sm:mx-0 sm:mt-0">
              <img src={imgOf(f)} alt="" className="h-36 w-36 rounded-xl object-cover sm:h-56 sm:w-56 lg:h-64 lg:w-64" />
            </button>}
          </div>
        </section>); })()}

        <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_340px] 2xl:grid-cols-[minmax(0,1fr)_420px]">
          <main className="min-w-0">
            {query.trim() && albums.length > 0 && (
              <section className="mb-8">
                <h2 className="font-display mb-3 text-xl font-bold">Albums</h2>
                <div className="scrollbar-none -mx-1 flex gap-4 overflow-x-auto px-1 pb-2">
                  {albums.map((a) => (
                    <button key={a.id} onClick={async () => { const s = await albumSongs(a.id); if (s.length) playAt(s, 0); }} className="hover-scale w-36 shrink-0 text-left">
                      <img src={imgOf(a)} alt="" className="aspect-square w-full rounded-2xl object-cover shadow-lg" loading="lazy" />
                      <p className="mt-2 truncate text-sm font-medium">{decode(a.name)}</p>
                      <p className="truncate text-xs text-muted-foreground">{artistOf(a)}</p>
                    </button>
                  ))}
                </div>
              </section>
            )}

            {!online && (
              <div className="mb-6 flex items-center gap-3 rounded-2xl vm-glass p-4"><WifiOff className="text-primary" /><p className="text-sm">You're offline — your downloaded songs still play.</p></div>
            )}

            {!query.trim() && view === "dashboard" && (
              <section className="vm-dashboard mb-8">
                <h2 className="font-display mb-3 text-xl font-bold">Your dashboard</h2>
                <div className="mb-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {[
                    { k: "Plays", v: stats.plays, I: Play },
                    { k: "Minutes listened", v: stats.mins, I: Clock },
                    { k: "Liked songs", v: liked.length, I: Heart },
                    { k: "Downloads", v: downloads.length, I: Download },
                  ].map(({ k, v, I }) => (
                    <div key={k} className="vm-dash-stat rounded-xl vm-glass p-3">
                      <I size={16} className="text-primary" />
                      <p className="font-display mt-1 text-2xl font-extrabold tabular-nums">{v}</p>
                      <p className="text-xs text-muted-foreground">{k}</p>
                    </div>
                  ))}
                </div>
                <div className="vm-dash-tiles grid grid-cols-2 gap-2 sm:grid-cols-3">
                  <LibTile strong title="Liked Songs" sub={`${liked.length} songs`} Icon={Heart} onClick={() => setPanel("liked")} />
                  <LibTile title="Downloads" sub={`${downloads.length} offline`} Icon={Download} onClick={() => setPanel("downloads")} />
                  <LibTile title="Recently played" sub={`${history.length} songs`} Icon={History} onClick={() => showList("Recently played", history.map((h) => h.song))} />
                  <LibTile title="On repeat" sub="Your most played" Icon={Repeat} onClick={() => showList("On repeat", [...history].sort((a, b) => b.count - a.count).slice(0, 25).map((h) => h.song))} />
                  <LibTile title="Vibe mixes" sub={`${aiMixes.length} remembered`} Icon={Wand2} onClick={() => { const m = aiMixes[0]; if (m) showList(`Vibe · ${m.text}`, m.songs); }} />
                  <LibTile title="Top artist" sub={stats.topArtists[0] ?? "Play more songs"} Icon={Mic2} onClick={() => { const a = stats.topArtists[0]; if (a) void openBrowse(`${a} hits`, `${a} songs`); }} />
                </div>
              </section>
            )}

            {onHome && (
              <section className="relative mb-6 min-w-0 overflow-hidden rounded-2xl border border-primary/40 p-3 sm:mb-8 sm:rounded-[2rem] sm:p-6"
                style={{ background: "linear-gradient(135deg, color-mix(in oklab, var(--primary) 18%, var(--card)), color-mix(in oklab, var(--accent) 16%, var(--card)))" }}>
                <h2 className="font-display mb-2 flex items-center gap-2 text-base font-bold sm:mb-1 sm:text-xl"><Wand2 className="text-primary" size={18} /> Vibe Engine</h2>
                <p className="mb-3 hidden text-sm text-muted-foreground sm:block">Tell AI your situation — it remembers your taste and plays the perfect queue.</p>
                <div className="flex items-center gap-2">
                  <input value={aiMood} onChange={(e) => setAiMood(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") void buildAiQueue(); }}
                    placeholder="Your mood or situation…"
                    className="min-w-0 flex-1 rounded-xl border border-border bg-background/60 px-3 py-2 text-base outline-none placeholder:text-muted-foreground focus:ring-2 focus:ring-primary sm:px-4 sm:py-3" />
                  <button onClick={() => void buildAiQueue()} disabled={aiLoading || !aiMood.trim()} aria-label="Create mix"
                    className="flex shrink-0 items-center justify-center gap-2 rounded-xl bg-primary px-3 py-2.5 text-sm font-bold text-primary-foreground transition active:scale-95 disabled:opacity-50 sm:px-5 sm:py-3">
                    {aiLoading ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />} <span className="hidden sm:inline">Create mix</span>
                  </button>
                </div>
                <div className="scrollbar-none mt-2 flex gap-2 overflow-x-auto pb-1 sm:mt-3 sm:flex-wrap">
                  {SITUATIONS.map((s) => (
                    <button key={s} disabled={aiLoading} onClick={() => void buildAiQueue(s)} className="shrink-0 whitespace-nowrap rounded-full border border-border bg-background/40 px-3 py-1.5 text-xs font-medium transition hover:border-primary hover:text-primary disabled:opacity-50">{s}</button>
                  ))}
                </div>
                {aiMixes.length > 0 && (
                  <div className="mt-4">
                    <p className="mb-2 text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">Remembered mixes</p>
                    <div className="scrollbar-none flex gap-2 overflow-x-auto pb-1">
                      {aiMixes.map((m) => (
                        <button key={m.at} onClick={() => { showList(`Vibe · ${m.text}`, m.songs); playAt(m.songs, 0); }}
                          className="flex shrink-0 items-center gap-2 rounded-full bg-card/80 py-1 pl-1 pr-3 text-xs font-medium ring-1 ring-border transition hover:ring-primary">
                          <img src={imgOf(m.songs[0], false)} alt="" className="h-7 w-7 rounded-full object-cover" /> {m.text}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                {aiError && <p className="mt-2 text-sm text-destructive">{aiError}</p>}
              </section>
            )}

            {onHome && (() => {
              const sugg = related.length ? related : home;
              const recent = history.slice(0, 15).map((h) => h.song);
              const rows: { title: string; Icon: typeof Disc3; list: Song[]; empty: string; more?: () => void }[] = [
                { title: "Suggested for you", Icon: Disc3, list: sugg, empty: "Play a song to get suggestions." },
                { title: "Recently played", Icon: History, list: recent, empty: "Songs you play will show here.", more: () => showList("Recently played", history.map((h) => h.song)) },
                { title: "Liked songs", Icon: Heart, list: liked, empty: "Tap the heart on any song to save it here.", more: () => setPanel("liked") },
              ];
              return rows.map((r) => (
                <section key={r.title} className="mb-6 min-w-0 lg:hidden">
                  <div className="mb-2 flex items-center justify-between gap-2">
                    <h2 className="font-display flex min-w-0 items-center gap-2 text-lg font-bold"><r.Icon className="shrink-0 text-primary" size={18} /> <span className="truncate">{r.title}</span></h2>
                    {r.more && r.list.length > 0 && <button onClick={r.more} className="shrink-0 text-xs font-semibold text-primary">See all</button>}
                  </div>
                  {r.list.length === 0 ? <p className="vm-glass rounded-xl px-3 py-3 text-sm text-muted-foreground">{r.empty}</p> : (
                    <div className="scrollbar-none -mx-1 flex snap-x gap-3 overflow-x-auto px-1 pb-2">
                      {r.list.slice(0, 15).map((s, i) => (
                        <button key={s.id} onClick={() => playAt(r.list, i)} className="group w-28 shrink-0 snap-start text-left sm:w-36">
                          <div className="relative">
                            <img src={imgOf(s)} alt="" className="aspect-square w-full rounded-2xl object-cover shadow-lg" loading="lazy" />
                            {current?.id === s.id && playing && <span className="absolute bottom-1.5 right-1.5 rounded-full bg-background/80 p-1"><Bars /></span>}
                          </div>
                          <p className="mt-1.5 truncate text-sm font-medium">{decode(s.name)}</p>
                          <p className="truncate text-xs text-muted-foreground">{artistOf(s)}</p>
                        </button>
                      ))}
                    </div>
                  )}
                </section>
              ));
            })()}

            {onHome && (
              <section className="mb-8">
                <h2 className="font-display mb-3 text-xl font-bold">Moods</h2>
                <div className="scrollbar-none -mx-1 flex snap-x gap-3 overflow-x-auto px-1 pb-2 sm:mx-0 sm:grid sm:grid-cols-4 sm:overflow-visible sm:px-0 md:grid-cols-6">
                  {MOODS.map((m) => (
                    <button key={m.id} onClick={() => openBrowse(`${m.name} songs`, `${lang} ${m.q}`, true, m.q)}
                      className={`group relative flex aspect-[4/3] w-28 shrink-0 snap-start flex-col justify-between overflow-hidden rounded-2xl border p-3 text-left transition hover:-translate-y-1 hover:border-primary sm:w-auto ${browse?.title === `${m.name} songs` ? "border-primary bg-primary/15" : "border-border bg-card/60"}`}>
                      <span className="absolute -right-4 -top-4 h-16 w-16 rounded-full bg-primary/20 blur-xl transition group-hover:bg-accent/30" />
                      <m.Icon size={22} className="relative text-primary" />
                      <span className="relative text-sm font-semibold">{m.name}</span>
                    </button>
                  ))}
                </div>
              </section>
            )}

            {onHome && browse && (
              <section id="vm-browse" className="mb-8 scroll-mt-24 rounded-3xl vm-glass p-4">
                <div className="mb-2 flex items-center justify-between">
                  <h2 className="font-display text-xl font-bold">{browse.title}</h2>
                  <button aria-label="Close" onClick={() => setBrowse(null)} className="rounded-full p-2 hover:bg-muted"><X size={18} /></button>
                </div>
                {browse.loading ? <div className="space-y-3">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="flex items-center gap-3"><div className="vm-skel h-12 w-12 rounded-xl" /><div className="flex-1"><div className="vm-skel h-3 w-2/3 rounded-full" /><div className="vm-skel mt-2 h-2.5 w-1/3 rounded-full" /></div></div>)}</div> : (
                  <div className="space-y-1">{browse.songs.map((s, i) => <Fragment key={s.id + i}>{SongRow({ s: s, list: browse.songs, i: i })}</Fragment>)}</div>
                )}
              </section>
            )}

            {onHome && history.length > 0 && (
              <section className="mb-8 hidden lg:block">
                <h2 className="font-display mb-3 text-xl font-bold">Recently listened</h2>
                <div className="scrollbar-none -mx-1 flex snap-x gap-3 overflow-x-auto px-1 pb-2 sm:mx-0 sm:grid sm:grid-cols-2 sm:overflow-visible sm:px-0">
                  {history.slice(0, 10).map((h, i, arr) => (
                    <button key={h.song.id} onClick={() => playAt(arr.map((x) => x.song), i)} className="group flex w-64 shrink-0 snap-start items-center gap-3 overflow-hidden rounded-xl bg-card/70 pr-3 text-left transition hover:bg-muted sm:w-auto">
                      <img src={imgOf(h.song, false)} alt="" className="h-14 w-14 shrink-0 object-cover" loading="lazy" />
                      <span className="min-w-0 flex-1 truncate text-sm font-semibold">{decode(h.song.name)}</span>
                      {current?.id === h.song.id && playing ? <Bars /> : <Play size={16} className="text-primary opacity-0 transition group-hover:opacity-100" />}
                    </button>
                  ))}
                </div>
              </section>
            )}

            {onHome && history.some((h) => h.count >= 2) && (
              <section className="mb-8">
                <h2 className="font-display mb-3 flex items-center gap-2 text-xl font-bold"><Repeat className="text-primary" size={20} /> On repeat for you</h2>
                <div className="scrollbar-none -mx-1 flex gap-4 overflow-x-auto px-1 pb-2">
                  {(() => { const top = [...history].filter((h) => h.count >= 2).sort((a, b) => b.count - a.count).slice(0, 12); return top.map((h, i) => (
                    <button key={h.song.id} onClick={() => playAt(top.map((x) => x.song), i)} className="group relative w-36 shrink-0 text-left sm:w-40 2xl:w-52">
                      <div className="relative overflow-hidden rounded-full bg-gradient-to-br from-primary to-accent p-[3px] shadow-lg">
                        <img src={imgOf(h.song)} alt="" className="aspect-square w-full rounded-full object-cover transition duration-500 group-hover:scale-105" loading="lazy" />
                      </div>
                      <span className="absolute right-1 top-1 rounded-full bg-primary px-2 py-0.5 text-[10px] font-bold text-primary-foreground">{h.count}× played</span>
                      <p className="mt-2 truncate text-center text-sm font-medium">{decode(h.song.name)}</p>
                    </button>
                  )); })()}
                </div>
              </section>
            )}

            {onHome && (
              <section className="mb-8">
                <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                  <h2 className="font-display flex items-center gap-2 text-xl font-bold"><Flame className="text-primary" size={20} /> Trending 2026</h2>
                  <div className="scrollbar-none -mx-1 flex max-w-full gap-2 overflow-x-auto px-1 py-1">
                    {(["telugu", "hindi", "tamil", "malayalam", "kannada", "english"] as const).map((l) => (
                      <button key={l} onClick={() => setLang(l)} className={`vm-chip shrink-0 capitalize ${lang === l ? "vm-chip-on" : ""}`}>{l}</button>
                    ))}
                  </div>
                </div>
                {trending.length === 0 && <div className="flex gap-4 overflow-hidden">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="w-40 shrink-0"><div className="vm-skel aspect-square rounded-3xl" /><div className="vm-skel mt-3 h-3 w-3/4 rounded-full" /><div className="vm-skel mt-2 h-2.5 w-1/2 rounded-full" /></div>)}</div>}
                <div className="scrollbar-none -mx-1 flex gap-4 overflow-x-auto px-1 pb-2">
                  {trending.map((s, i) => (
                    <button key={s.id} onClick={() => playAt(trending, i)} className="group w-36 shrink-0 text-left sm:w-40 2xl:w-52">
                      <div className="vm-card relative overflow-hidden rounded-2xl">
                        <img src={imgOf(s)} alt="" className="aspect-square w-full object-cover transition duration-500 group-hover:scale-110" loading="lazy" />
                        <span className="font-display absolute left-2 top-1 text-4xl font-extrabold text-primary drop-shadow-lg">{i + 1}</span>
                      </div>
                      <p className="mt-2 truncate text-sm font-medium">{decode(s.name)}</p>
                      <p className="truncate text-xs text-muted-foreground">{artistOf(s)}</p>
                    </button>
                  ))}
                </div>
              </section>
            )}

            {onHome && (
              <section className="mb-8">
                <h2 className="font-display mb-3 flex items-center gap-2 text-xl font-bold"><History className="text-primary" size={20} /> Golden oldies</h2>
                {oldies.length === 0 && <Loader2 className="my-6 animate-spin text-primary" />}
                <div className="scrollbar-none -mx-1 flex gap-4 overflow-x-auto px-1 pb-2">
                  {oldies.map((s, i) => (
                    <button key={s.id} onClick={() => playAt(oldies, i)} className="group w-36 shrink-0 text-left sm:w-40 2xl:w-52">
                      <div className="vm-card relative overflow-hidden rounded-2xl">
                        <img src={imgOf(s)} alt="" className="aspect-square w-full object-cover transition duration-500 group-hover:scale-110" loading="lazy" />
                        <span className="absolute bottom-2 right-2 flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground opacity-0 shadow-xl transition group-hover:opacity-100"><Play size={16} className="fill-current" /></span>
                      </div>
                      <p className="mt-2 truncate text-sm font-medium">{decode(s.name)}</p>
                      <p className="truncate text-xs text-muted-foreground">{s.year ?? artistOf(s)}</p>
                    </button>
                  ))}
                </div>
              </section>
            )}

            {onHome && (
              <section className="mb-8">
                <h2 className="font-display mb-3 text-xl font-bold">Top singers</h2>
                <div className="scrollbar-none -mx-1 flex gap-5 overflow-x-auto px-1 pb-2">
                  {SINGERS.map((n) => (
                    <button key={n} onClick={() => void openSinger(n)} className="group w-24 shrink-0 text-center">
                      <div className="mx-auto h-24 w-24 rounded-full bg-gradient-to-br from-primary to-accent p-[3px] transition group-hover:scale-105">
                        {singerImgs[n] ? <img src={singerImgs[n]} alt={n} className="h-full w-full rounded-full object-cover ring-2 ring-background" loading="lazy" />
                          : <div className="font-display flex h-full w-full items-center justify-center rounded-full bg-card text-xl font-bold">{n.split(" ").map((w) => w[0]).slice(0, 2).join("")}</div>}
                      </div>
                      <p className="mt-2 line-clamp-2 text-xs font-medium">{n}</p>
                    </button>
                  ))}
                </div>
              </section>
            )}

            {onHome && home.length > 0 && (
              <section className="mb-8">
                <h2 className="font-display mb-3 text-xl font-bold">Your {mood.key} mix</h2>
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
                  {home.slice(0, 8).map((s, i) => (
                    <button key={s.id} onClick={() => playAt(home, i)} className="group relative text-left">
                      <div className="vm-card relative overflow-hidden rounded-2xl">
                        <img src={imgOf(s)} alt="" className="aspect-square w-full object-cover transition duration-500 group-hover:scale-110" loading="lazy" />
                        <span className="absolute bottom-2 right-2 flex h-11 w-11 translate-y-3 items-center justify-center rounded-full bg-primary text-primary-foreground opacity-0 shadow-xl transition group-hover:translate-y-0 group-hover:opacity-100"><Play size={18} className="fill-current" /></span>
                      </div>
                      <p className="mt-2 truncate text-sm font-medium">{decode(s.name)}</p>
                      <p className="truncate text-xs text-muted-foreground">{artistOf(s)}</p>
                    </button>
                  ))}
                </div>
              </section>
            )}

            <section className={(query.trim() || view !== "home" || home.length <= 8) ? "hidden" : ""}>
              <h2 className="font-display mb-3 text-xl font-bold">{query.trim() ? "Songs" : "More for you"}</h2>
              {query.trim() && !loading && results.length === 0 && <p className="text-muted-foreground">No songs found. Try another search.</p>}
              <div className="space-y-1">
                {(query.trim() ? listToShow : home.slice(8)).map((s, i) => (
                  <Fragment key={s.id + i}>{SongRow({ s: s, list: listToShow, i: query.trim() ? i : i + 8 })}</Fragment>
                ))}
              </div>
            </section>
          </main>

          <aside className="hidden space-y-6 lg:block">
            <div className="rounded-3xl vm-glass p-4 ">
              <h3 className="font-display mb-2 flex items-center gap-2 font-bold"><Download size={18} className="text-primary" /> Downloads <span className="text-xs font-normal text-muted-foreground">· plays offline</span></h3>
              {downloads.length === 0 ? <p className="text-sm text-muted-foreground">Tap the download icon on any song to keep it for offline listening.</p> : (
                <div className="space-y-1">{downloads.map((s, i) => <Fragment key={s.id}>{SongRow({ s: s, list: downloads, i: i })}</Fragment>)}</div>
              )}
            </div>
            <div className="rounded-3xl vm-glass p-4 ">
              <h3 className="font-display mb-2 flex items-center gap-2 font-bold"><Disc3 size={18} className="text-primary" /> Suggested for you</h3>
              {related.length === 0 ? <p className="text-sm text-muted-foreground">Play a song to get similar track suggestions.</p> : (
                <div className="space-y-1">{related.slice(0, 8).map((s, i) => <Fragment key={s.id}>{SongRow({ s: s, list: related, i: i })}</Fragment>)}</div>
              )}
            </div>
            <div className="rounded-3xl vm-glass p-4 ">
              <h3 className="font-display mb-2 flex items-center gap-2 font-bold"><Heart size={18} className="text-primary" /> Liked songs</h3>
              {liked.length === 0 ? <p className="text-sm text-muted-foreground">Tap the heart on any song to save it here.</p> : (
                <div className="space-y-1">{liked.map((s, i) => <Fragment key={s.id}>{SongRow({ s: s, list: liked, i: i })}</Fragment>)}</div>
              )}
            </div>
          </aside>
        </div>

        <footer className="py-10 text-center"><Signature className="mx-auto h-12 w-48" /></footer>
      </div>

      {/* mini player */}
      {current && !full && (
        <div className="vm-mini-player vm-glass-strong animate-fade-in fixed inset-x-3 bottom-[calc(5.75rem+env(safe-area-inset-bottom))] z-40 mx-auto max-w-3xl rounded-2xl sm:bottom-4 lg:inset-x-auto lg:left-64 lg:right-6 lg:bottom-4 lg:max-w-none 2xl:left-72">
          <div className="mx-4 mt-2 h-[3px] overflow-hidden rounded-full bg-foreground/10"><div className="vm-progress h-full rounded-full transition-[width] duration-500 ease-linear" style={{ width: `${dur ? (time / dur) * 100 : 0}%` }} /></div>
          <div className="flex items-center gap-3 p-3">
            <button onClick={() => setFull(true)} className="flex min-w-0 flex-1 items-center gap-3 text-left">
              <Artwork src={imgOf(current, false)} frame={frame} playing={playing} size="sm" />
              <div className="min-w-0">
                <p className="truncate font-medium">{decode(current.name)}</p>
                <p className="truncate text-xs text-muted-foreground">{artistOf(current)}</p>
              </div>
            </button>
            <IconBtn label="Like" onClick={() => toggleLike(current)}><Heart size={20} className={isLiked ? "fill-primary text-primary" : ""} /></IconBtn>
            <IconBtn label="Queue" onClick={() => setPanel("queue")} className="hidden md:flex"><ListMusic size={19} /></IconBtn>
            <div className="hidden w-24 items-center gap-1 lg:flex"><button aria-label="Mute" onClick={() => setMuted(!muted)} className="text-muted-foreground hover:text-foreground">{muted || volume === 0 ? <VolumeX size={16} /> : <Volume2 size={16} />}</button><input type="range" min={0} max={1} step={0.01} value={muted ? 0 : volume} onChange={(e) => { setVolume(Number(e.target.value)); setMuted(false); }} className="w-full accent-[var(--primary)]" aria-label="Volume" /></div>
            <IconBtn label="Previous" onClick={prev} className="hidden sm:flex"><SkipBack size={20} /></IconBtn>
            <PlayBtn playing={playing} buffering={buffering} onClick={toggle} />
            <IconBtn label="Next" onClick={next}><SkipForward size={20} /></IconBtn>
          </div>
        </div>
      )}

      {/* mobile tab bar */}
      {!full && (
        <nav aria-label="Primary navigation" className="vm-mobile-nav vm-glass-strong fixed inset-x-3 bottom-[calc(0.65rem+env(safe-area-inset-bottom))] z-40 grid grid-cols-4 rounded-2xl p-1 sm:hidden">
          {([
            { k: "Home", I: HomeIcon, on: view === "home" && !panel, go: () => { setPanel(null); setView("home"); window.scrollTo({ top: 0 }); } },
            { k: "Dashboard", I: LayoutDashboard, on: view === "dashboard" && !panel, go: () => { setPanel(null); setQuery(""); setView("dashboard"); window.scrollTo({ top: 0 }); } },
            { k: "Liked", I: Heart, on: panel === "liked", go: () => setPanel("liked") },
            { k: "Downloads", I: Download, on: panel === "downloads", go: () => setPanel("downloads") },
          ] as const).map(({ k, I, on, go }) => (
            <button key={k} onClick={go} className={`relative flex h-14 flex-col items-center justify-center gap-0.5 rounded-[1.4rem] text-[10px] font-semibold tracking-wide transition-all duration-300 ${on ? "bg-foreground/10 text-foreground" : "text-muted-foreground"}`}>
              <I size={20} className={on ? "text-primary" : ""} /> {k}
            </button>
          ))}
        </nav>
      )}

      {playlist && (
        <div className="vm-library-screen animate-fade-in fixed inset-0 z-[45] overflow-y-auto bg-background pb-44">
          <div className="relative overflow-hidden px-4 pb-6 pt-[calc(1rem+env(safe-area-inset-top))] sm:px-8">
            {playlist.img && <img src={playlist.img} alt="" className="absolute inset-0 h-full w-full scale-125 object-cover opacity-30 blur-3xl" />}
            <div className="relative mx-auto max-w-4xl">
              <button aria-label="Back" onClick={() => setPlaylist(null)} className="flex h-10 w-10 items-center justify-center rounded-full bg-card/70 backdrop-blur"><ChevronDown size={22} /></button>
              <div className="mt-4 flex flex-col items-center gap-4 text-center sm:flex-row sm:items-end sm:text-left">
                <div className="h-40 w-40 shrink-0 rounded-full bg-gradient-to-br from-primary to-accent p-1 shadow-2xl sm:h-48 sm:w-48">
                  {playlist.img ? <img src={playlist.img} alt="" className="h-full w-full rounded-full object-cover" /> : <div className="flex h-full w-full items-center justify-center rounded-full bg-card"><Disc3 size={48} className="text-primary" /></div>}
                </div>
                <div className="min-w-0">
                  <p className="text-[11px] font-semibold uppercase tracking-widest text-primary">Artist playlist</p>
                  <h2 className="font-display mt-1 break-words text-[clamp(1.8rem,8vw,3.5rem)] font-extrabold leading-tight">{playlist.title}</h2>
                  <p className="mt-1 text-sm text-muted-foreground">{playlist.loading ? "Loading songs…" : `${playlist.songs.length} songs · VIVEK'S MUSIX`}</p>
                </div>
              </div>
              {!playlist.loading && playlist.songs.length > 0 && (
                <div className="mt-5 flex justify-center gap-3 sm:justify-start">
                  <button onClick={() => playAt(playlist.songs, 0)} className="flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground shadow-lg transition hover:scale-105"><Play size={16} className="fill-current" /> Play all</button>
                  <button onClick={() => { setShuffle(true); playAt(playlist.songs, Math.floor(Math.random() * playlist.songs.length)); }} className="flex items-center gap-2 rounded-full vm-glass px-6 py-3 text-sm font-semibold backdrop-blur"><Shuffle size={16} className="text-primary" /> Shuffle</button>
                </div>
              )}
            </div>
          </div>
          <div className="mx-auto max-w-4xl px-2 sm:px-6">
            {playlist.loading ? <Loader2 className="mx-auto my-10 animate-spin text-primary" /> : playlist.songs.length === 0 ? <p className="p-6 text-center text-muted-foreground">No songs found right now.</p> : (
              <div className="space-y-1">{playlist.songs.map((s, i) => <Fragment key={s.id + i}>{SongRow({ s: s, list: playlist.songs, i: i })}</Fragment>)}</div>
            )}
          </div>
        </div>
      )}

      {/* full player */}
      {current && full && (
        <div className="vm-now-playing animate-fade-in fixed inset-0 z-50 overflow-y-auto bg-background">
          <div className="pointer-events-none fixed inset-0">
            <img src={imgOf(current)} alt="" className="vm-drift h-full w-full scale-150 object-cover opacity-60 blur-[80px] saturate-150" />
            <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-background/60 to-background/95" />
          </div>
          <div className="vm-player-layout relative mx-auto flex min-h-full max-w-6xl flex-col px-4 pb-[calc(1.25rem+env(safe-area-inset-bottom))] pt-[calc(0.75rem+env(safe-area-inset-top))] sm:px-8 sm:py-5 2xl:max-w-[1600px]">
            <div className="flex items-center justify-between">
              <div className="flex shrink-0 items-center gap-1">
                <IconBtn label="Close" onClick={() => setFull(false)}><ChevronDown size={26} /></IconBtn>
                <IconBtn label="Share" onClick={() => { if (!current) return; const t = `${decode(current.name)} – ${artistOf(current)} on VIVEK'S MUSIX`; if (navigator.share) void navigator.share({ title: t, text: t, url: location.href }).catch(() => {}); else void navigator.clipboard?.writeText(`${t} ${location.href}`); }}><Share2 size={20} /></IconBtn>
              </div>
              <div className="min-w-0 text-center">
                <p className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Playing from</p>
                <p className="font-display truncate text-sm font-bold">{browse?.title ?? <>VIVEK'S <span className="text-primary">MUSIX</span></>}</p>
              </div>
              <IconBtn label="Frame" onClick={() => setFrame(FRAMES[(FRAMES.indexOf(frame) + 1) % FRAMES.length]!)}><Frame size={20} /></IconBtn>
            </div>

            <div className="grid flex-1 items-center gap-4 py-3 sm:gap-8 sm:py-6 lg:grid-cols-2 lg:gap-14">
                <div className="vm-player-art relative flex items-center justify-center py-2 sm:py-6">
                <div className={`absolute h-56 w-56 rounded-full bg-gradient-to-br from-primary to-accent blur-3xl sm:h-[28rem] sm:w-[28rem] ${playing ? "vm-pulse" : "opacity-20"}`} />
                <div className="relative flex flex-col items-center gap-5">
                {jamLive && <span className="vm-chip relative z-10 inline-flex items-center gap-1.5 !py-1 !text-[11px] text-primary"><Users size={12} /> Jam {jam.code} · {jam.members.length} listening</span>}
                <div className="relative vm-reflect"><Artwork src={imgOf(current)} frame={frame} playing={playing} /></div>
                </div>
              </div>

              <div className="vm-player-controls vm-np-card flex min-w-0 flex-col rounded-[2rem] p-5 sm:p-7">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h2 className="font-display line-clamp-2 text-[clamp(1.75rem,7vw,3.75rem)] font-extrabold leading-[1.02] tracking-tight [overflow-wrap:anywhere]">{decode(current.name)}</h2>
                    <p className="mt-1 truncate text-lg text-muted-foreground">{artistOf(current)}</p>
                    <p className="truncate text-xs text-muted-foreground/80">{decode(current.album?.name)}{current.year ? ` · ${current.year}` : ""}</p>
                    <p className="vm-chip mt-3 inline-flex items-center gap-1.5 !py-1 !text-[11px]"><Clock size={12} className="text-primary" /> You listened {fmt(listen.songs[current.id] ?? 0)}</p>
                  </div>
                  <div className="flex shrink-0 items-center">
                    {DlBtn({ s: current, size: 22 })}
                    <IconBtn label="Like" onClick={() => toggleLike(current)}><Heart size={26} className={isLiked ? "fill-primary text-primary" : ""} /></IconBtn>
                  </div>
                </div>

                <div className="mt-3 sm:mt-6"><Visualizer analyser={analyser} playing={playing} /></div>

                <div className="mt-3">
                  <input type="range" min={0} max={dur || 0} step={0.5} value={time} onChange={(e) => { if (audioRef.current) audioRef.current.currentTime = Number(e.target.value); }}
                    className="vm-range w-full" style={{ ["--p" as string]: `${dur ? (time / dur) * 100 : 0}%` }} aria-label="Seek" />
                  <div className="flex justify-between text-xs tabular-nums text-muted-foreground"><span>{fmt(time)}</span><span>{fmt(dur)}</span></div>
                </div>

                <div className="vm-np-transport mt-3 flex items-center justify-between rounded-full px-2 py-1.5 sm:mt-5">
                  <IconBtn label="Shuffle" onClick={() => setShuffle(!shuffle)}><Shuffle size={22} className={shuffle ? "text-primary" : ""} /></IconBtn>
                  <IconBtn label="Previous" onClick={prev} className="h-12 w-12 sm:h-14 sm:w-14"><SkipBack size={28} className="fill-current" /></IconBtn>
                  <PlayBtn playing={playing} buffering={buffering} onClick={toggle} big />
                  <IconBtn label="Next" onClick={next} className="h-12 w-12 sm:h-14 sm:w-14"><SkipForward size={28} className="fill-current" /></IconBtn>
                  <IconBtn label="Repeat" onClick={() => setRepeat(repeat === "off" ? "all" : repeat === "all" ? "one" : "off")}>
                    {repeat === "one" ? <Repeat1 size={22} className="text-primary" /> : <Repeat size={22} className={repeat === "all" ? "text-primary" : ""} />}
                  </IconBtn>
                </div>

                <div className="mt-5 flex items-center gap-3">
                  <IconBtn label="Mute" onClick={() => setMuted(!muted)}>{muted || volume === 0 ? <VolumeX size={18} /> : <Volume2 size={18} />}</IconBtn>
                  <input type="range" min={0} max={1} step={0.01} value={muted ? 0 : volume} onChange={(e) => { setVolume(Number(e.target.value)); setMuted(false); }} className="w-full accent-[var(--primary)]" aria-label="Volume" />
                </div>

                <div className="mt-5">
                  <p className="mb-2 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-widest text-muted-foreground"><Headphones size={14} className="text-primary" /> Sound</p>
                  <div className="grid grid-cols-3 gap-2 min-[480px]:grid-cols-5">
                    {SOUND_MODES.map((m) => (
                      <button key={m.id} onClick={() => { ensureAudio(); setSound(m.id); }}
                        className={`rounded-2xl border px-2 py-2.5 text-center transition ${sound === m.id ? "border-primary bg-primary/15 text-primary" : "vm-glass hover:border-primary/60"}`}>
                        <span className="block text-xs font-bold">{m.name}</span>
                        <span className="block text-[10px] text-muted-foreground">{m.hint}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="mt-5 grid grid-cols-2 gap-2 min-[420px]:grid-cols-4">
                  <PillBtn onClick={() => setPanel("lyrics")}><Mic2 size={16} /> Lyrics</PillBtn>
                  <PillBtn onClick={() => setPanel("queue")}><ListMusic size={16} /> Queue</PillBtn>
                  <PillBtn onClick={() => setSleepAt(sleepAt == null ? Date.now() + 15 * 60000 : (sleepAt - Date.now()) < 16 * 60000 ? Date.now() + 30 * 60000 : (sleepAt - Date.now()) < 31 * 60000 ? Date.now() + 60 * 60000 : null)}>
                    <Timer size={16} className={sleepAt ? "text-primary" : ""} /> {sleepAt ? `${Math.max(1, Math.ceil((sleepAt - Date.now()) / 60000))}m` : "Sleep"}
                  </PillBtn>
                  <PillBtn onClick={() => setPanel("themes")}><Palette size={16} /> Themes</PillBtn>
                  <PillBtn onClick={() => { const S = [0.75, 1, 1.25, 1.5, 2]; setSpeed(S[(S.indexOf(speed) + 1) % S.length] ?? 1); }}><Gauge size={16} className={speed !== 1 ? "text-primary" : ""} /> {speed === 1 ? "Speed" : `${speed}x`}</PillBtn>
                </div>
                <Signature className="mx-auto mt-6 h-10 w-40" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* background-play banner (visible when returning) */}
      {hidden && null}

      {/* side panels */}
      {panel && (
        <div className="fixed inset-0 z-[60] flex justify-end bg-background/60 backdrop-blur-sm" onClick={() => setPanel(null)}>
          <div className="vm-side-panel animate-slide-in-right h-full w-full max-w-md overflow-y-auto border-l border-border bg-card p-5" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-display text-xl font-bold capitalize">{panel === "liked" ? "Liked songs" : panel}</h3>
              <IconBtn label="Close" onClick={() => setPanel(null)}><X size={20} /></IconBtn>
            </div>

            {panel === "themes" && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  {THEMES.map((t) => (
                    <button key={t.id} onClick={() => setTheme(t.id)} className={`overflow-hidden rounded-2xl border-2 text-left transition ${theme === t.id ? "border-primary" : "border-border"}`}>
                      <div className="flex h-16" style={{ background: t.c[0] }}>
                        <div className="m-auto h-8 w-8 rounded-full" style={{ background: t.c[1], boxShadow: `0 0 20px ${t.c[1]}` }} />
                      </div>
                      <p className="px-3 py-2 text-sm font-medium">{t.name}</p>
                    </button>
                  ))}
                </div>
                <h4 className="font-display mb-2 mt-6 font-bold">Photo frame</h4>
                <div className="flex flex-wrap gap-2">
                  {FRAMES.map((f) => (
                    <button key={f} onClick={() => setFrame(f)} className={`rounded-full px-4 py-1.5 text-sm capitalize ${frame === f ? "bg-primary text-primary-foreground" : "bg-muted"}`}>{f}</button>
                  ))}
                </div>
              </>
            )}

            {panel === "jam" && (
              <div className="space-y-5">
                <p className="text-sm text-muted-foreground">Listen together with friends. Everyone hears the same song at the same moment, and anyone in the Jam can change the song.</p>
                {!jam.code ? (
                  <>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-muted-foreground">Your name
                      <input value={jamName} maxLength={24} onChange={(e) => { setJamName(e.target.value); localStorage.setItem("vm-name", e.target.value); }} placeholder="e.g. Vivek" className="mt-1.5 w-full rounded-xl border border-border bg-background px-4 py-3 text-base font-medium normal-case tracking-normal text-foreground outline-none focus:border-primary" />
                    </label>
                    <button onClick={() => jam.create(jamName)} className="flex w-full items-center justify-center gap-2 rounded-full bg-primary py-3.5 text-sm font-bold text-primary-foreground"><Users size={18} /> Start a Jam</button>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" />or join one<span className="h-px flex-1 bg-border" /></div>
                    <form onSubmit={(e) => { e.preventDefault(); jam.join(jamInput, jamName); }} className="flex gap-2">
                      <input value={jamInput} onChange={(e) => setJamInput(e.target.value.toUpperCase())} maxLength={8} placeholder="Jam code" aria-label="Jam code" className="min-w-0 flex-1 rounded-xl border border-border bg-background px-4 py-3 font-mono text-lg tracking-[0.3em] outline-none focus:border-primary" />
                      <button type="submit" className="rounded-xl bg-muted px-5 text-sm font-bold">Join</button>
                    </form>
                    {jam.status === "error" && <p className="text-sm text-destructive">Couldn't join. Check the code and try again.</p>}
                  </>
                ) : (
                  <>
                    <div className="rounded-2xl border border-border bg-background/60 p-5 text-center">
                      <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Jam code</p>
                      <p className="font-display mt-2 font-mono text-4xl font-extrabold tracking-[0.25em] text-primary">{jam.code}</p>
                      <button onClick={() => { void navigator.clipboard?.writeText(jam.code ?? ""); setJamCopied(true); setTimeout(() => setJamCopied(false), 1500); }} className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-muted px-4 py-1.5 text-xs font-bold"><Copy size={14} /> {jamCopied ? "Copied" : "Copy code"}</button>
                      <p className="mt-3 text-xs text-muted-foreground">{jam.status === "live" ? "Share this code so friends can join." : jam.status === "error" ? "Connection lost. Leave and try again." : "Connecting…"}</p>
                    </div>
                    <div>
                      <h4 className="font-display mb-2 font-bold">In this Jam ({jam.members.length})</h4>
                      <div className="space-y-1.5">{jam.members.map((m, i) => (
                        <div key={m.id} className="flex items-center gap-3 rounded-xl bg-muted/50 px-3 py-2 text-sm">
                          <span className="grid h-8 w-8 place-items-center rounded-full bg-primary/20 font-bold text-primary">{m.name.slice(0, 1).toUpperCase()}</span>
                          <span className="flex-1 truncate font-medium">{m.name}</span>
                          {i === 0 && <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Host</span>}
                        </div>))}</div>
                    </div>
                    <button onClick={jam.leave} className="flex w-full items-center justify-center gap-2 rounded-full border border-border py-3 text-sm font-bold"><LogOut size={16} /> Leave Jam</button>
                  </>
                )}
              </div>
            )}

            {panel === "queue" && (
              <div className="space-y-1">{queue.map((s, i) => <Fragment key={s.id + i}>{SongRow({ s: s, list: queue, i: i })}</Fragment>)}</div>
            )}
            {panel === "liked" && (liked.length ? (
              <>
                <button onClick={() => playAt(liked, 0)} className="mb-3 flex w-full items-center justify-center gap-2 rounded-full bg-primary py-3 text-sm font-bold text-primary-foreground"><Play size={16} className="fill-current" /> Play all</button>
                <div className="space-y-1">{liked.map((s, i) => <Fragment key={s.id}>{SongRow({ s: s, list: liked, i: i })}</Fragment>)}</div>
              </>
            ) : <p className="text-muted-foreground">Tap the heart on any song to save it here.</p>)}
            {panel === "downloads" && (downloads.length ? (
              <>
                <button onClick={() => playAt(downloads, 0)} className="mb-3 flex w-full items-center justify-center gap-2 rounded-full bg-primary py-3 text-sm font-bold text-primary-foreground"><Play size={16} className="fill-current" /> Play offline</button>
                <div className="space-y-1">{downloads.map((s, i) => <Fragment key={s.id}>{SongRow({ s: s, list: downloads, i: i })}</Fragment>)}</div>
              </>
            ) : <p className="text-muted-foreground">Tap the download icon on any song to keep it for offline listening.</p>)}

            {panel === "lyrics" && (
              <div ref={lyricRef} className="space-y-4 pb-20">
                {lyrics === "loading" && <Loader2 className="mx-auto animate-spin text-primary" />}
                {lyrics === null && <p className="text-muted-foreground">Lyrics not available for this song.</p>}
                {lyrics && lyrics !== "loading" && (lyrics.synced.length ? lyrics.synced.map((l, i) => (
                  <p key={i} data-line={i} onClick={() => { if (audioRef.current) audioRef.current.currentTime = l.t; }}
                    className={`font-display cursor-pointer text-2xl font-bold transition ${i === activeLine ? "scale-[1.02] text-primary" : "text-muted-foreground/60"}`}>{l.text || "♪"}</p>
                )) : <p className="whitespace-pre-line text-lg">{lyrics.plain || "Lyrics not available."}</p>)}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function Bars() {
  return (
    <span className="flex h-4 items-end gap-0.5">
      {[0, 1, 2].map((i) => <span key={i} className="vm-bar w-1 rounded-full bg-primary" style={{ height: 16, animationDelay: `${i * 0.15}s` }} />)}
    </span>
  );
}
function IconBtn({ children, label, onClick, className = "" }: { children: React.ReactNode; label: string; onClick: () => void; className?: string }) {
  return <button aria-label={label} title={label} onClick={onClick} className={`flex h-10 w-10 items-center justify-center rounded-full text-foreground transition duration-300 hover:bg-foreground/10 active:scale-90 ${className}`}>{children}</button>;
}
function PillBtn({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return <button onClick={onClick} className="flex items-center justify-center gap-2 rounded-full vm-glass py-2.5 text-sm font-medium backdrop-blur-xl transition hover:border-primary">{children}</button>;
}
function PlayBtn({ playing, buffering, onClick, big }: { playing: boolean; buffering: boolean; onClick: () => void; big?: boolean }) {
  const s = big ? "h-16 w-16 sm:h-20 sm:w-20" : "h-11 w-11";
  return (
    <button aria-label={playing ? "Pause" : "Play"} onClick={onClick} className={`${s} flex items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition duration-300 hover:scale-105 active:scale-95 ${big ? "vm-playglow" : ""}`}>
      {buffering ? <Loader2 className="animate-spin" /> : playing ? <Pause size={big ? 34 : 20} className="fill-current" /> : <Play size={big ? 34 : 20} className="ml-1 fill-current" />}
    </button>
  );
}
function LibTile({ title, sub, Icon, onClick, strong }: { title: string; sub: string; Icon: typeof Heart; onClick: () => void; strong?: boolean }) {
  return (
    <button onClick={onClick} className={`group flex items-center gap-3 overflow-hidden rounded-2xl border p-2 pr-3 text-left transition hover:-translate-y-0.5 hover:border-primary ${strong ? "border-primary/40 bg-gradient-to-br from-primary/25 to-accent/20" : "border-border bg-card/60"}`}>
      <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent text-primary-foreground shadow"><Icon size={20} className={strong ? "fill-current" : ""} /></span>
      <span className="min-w-0"><span className="block truncate text-sm font-bold">{title}</span><span className="block truncate text-xs text-muted-foreground">{sub}</span></span>
    </button>
  );
}
function Visualizer({ analyser, playing }: { analyser: AnalyserNode | null; playing: boolean }) {
  const ref = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (!analyser || !playing) return;
    const bars = Array.from(ref.current?.children ?? []) as HTMLElement[];
    const data = new Uint8Array(analyser.frequencyBinCount);
    let raf = 0;
    const loop = () => {
      analyser.getByteFrequencyData(data);
      const step = Math.max(1, Math.floor((data.length * 0.6) / Math.max(1, bars.length)));
      bars.forEach((b, i) => { const v = data[Math.min(data.length - 1, i * step + 1)] ?? 0; b.style.transform = `scaleY(${Math.max(0.08, v / 255)})`; });
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => cancelAnimationFrame(raf);
  }, [analyser, playing]);
  const live = !!analyser;
  return (
    <div ref={ref} className="flex h-10 items-end gap-[3px] sm:h-16" aria-hidden>
      {Array.from({ length: 36 }).map((_, i) => (
        <span key={i} className={`h-full flex-1 origin-bottom rounded-full bg-gradient-to-t from-primary to-accent ${live ? "transition-transform duration-75" : `vm-bar ${playing ? "" : "vm-paused"}`}`}
          style={live ? { transform: "scaleY(0.08)" } : { animationDelay: `${(i % 7) * 0.11}s`, animationDuration: `${0.6 + (i % 5) * 0.15}s` }} />
      ))}
    </div>
  );
}
