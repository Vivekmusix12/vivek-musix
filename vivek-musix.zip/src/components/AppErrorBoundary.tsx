import { Component, type ReactNode } from "react";
import { reportLovableError } from "@/lib/lovable-error-reporting";

/** Catches unexpected crashes in the music app and offers a one-tap recovery instead of a stuck screen. */
export class AppErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null; key: number }> {
  override state = { error: null as Error | null, key: 0 };
  static getDerivedStateFromError(error: Error) { return { error }; }
  override componentDidCatch(error: Error) {
    console.error("[VIVEK] app crashed", error);
    reportLovableError(error, { boundary: "vivek_app" });
  }
  override render() {
    if (!this.state.error) return <div key={this.state.key} className="contents">{this.props.children}</div>;
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-6 text-center">
        <div className="max-w-sm">
          <h1 className="font-display text-2xl font-bold text-foreground">Something went wrong</h1>
          <p className="mt-2 text-sm text-muted-foreground">VIVEK'S MUSIX hit a problem. Your liked songs and downloads are safe.</p>
          <div className="mt-6 flex justify-center gap-2">
            <button onClick={() => this.setState((s) => ({ error: null, key: s.key + 1 }))} className="rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground">Try again</button>
            <button onClick={() => window.location.reload()} className="rounded-full border border-border px-5 py-2 text-sm font-semibold text-foreground">Reload</button>
          </div>
        </div>
      </div>
    );
  }
}
