import { useCallback, useEffect, useRef, useState } from "react";
import type { RealtimeChannel } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

/** Jam: friends join a live room by code; everyone hears the same song at the same spot and anyone can change it. */
export type JamMsg =
  | { t: "play"; song: unknown; pos: number; playing: boolean; at: number }
  | { t: "pause"; pos: number }
  | { t: "resume"; pos: number; at: number }
  | { t: "seek"; pos: number; at: number }
  | { t: "sync" };

export type JamMember = { id: string; name: string };

const makeCode = () => {
  const c = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 6; i++) s += c[Math.floor(Math.random() * c.length)];
  return s;
};

export function useJam(onMsg: (m: JamMsg) => void) {
  const [code, setCode] = useState<string | null>(null);
  const [members, setMembers] = useState<JamMember[]>([]);
  const [status, setStatus] = useState<"idle" | "connecting" | "live" | "error">("idle");
  const chan = useRef<RealtimeChannel | null>(null);
  const me = useRef("");
  const handler = useRef(onMsg);
  handler.current = onMsg;

  const leave = useCallback(() => {
    if (chan.current) void supabase.removeChannel(chan.current);
    chan.current = null; setCode(null); setMembers([]); setStatus("idle");
  }, []);

  const connect = useCallback((raw: string, name: string, askSync: boolean) => {
    const c = raw.trim().toUpperCase();
    if (!/^[A-Z0-9]{4,8}$/.test(c)) { setStatus("error"); return; }
    if (chan.current) void supabase.removeChannel(chan.current);
    me.current = me.current || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
    setStatus("connecting"); setCode(c);
    const ch = supabase.channel(`jam-${c}`, { config: { broadcast: { self: false }, presence: { key: me.current } } });
    ch.on("broadcast", { event: "jam" }, ({ payload }) => handler.current(payload as JamMsg));
    ch.on("presence", { event: "sync" }, () => {
      const st = ch.presenceState<{ name: string }>();
      setMembers(Object.entries(st).map(([id, v]) => ({ id, name: v[0]?.name ?? "Listener" })).sort((a, b) => a.id.localeCompare(b.id)));
    });
    ch.subscribe(async (s) => {
      if (s === "SUBSCRIBED") {
        setStatus("live");
        await ch.track({ name: name.slice(0, 24) || "Listener" });
        if (askSync) void ch.send({ type: "broadcast", event: "jam", payload: { t: "sync" } satisfies JamMsg });
      } else if (s === "CHANNEL_ERROR" || s === "TIMED_OUT") setStatus("error");
    });
    chan.current = ch;
  }, []);

  const create = useCallback((name: string) => connect(makeCode(), name, false), [connect]);
  const join = useCallback((c: string, name: string) => connect(c, name, true), [connect]);
  const send = useCallback((m: JamMsg) => {
    if (chan.current && status === "live") void chan.current.send({ type: "broadcast", event: "jam", payload: m });
  }, [status]);

  useEffect(() => () => { if (chan.current) void supabase.removeChannel(chan.current); }, []);

  /** One person (first in the room) moves the jam to the next song when a track ends, so phones don't fight. */
  const isLeader = members.length === 0 || members[0]?.id === me.current;
  return { code, members, status, create, join, leave, send, isLeader };
}
