import { createOpenAI } from "@ai-sdk/openai";
import { streamText, type ModelMessage } from "ai";

import { createLovableAiGatewayRunIdFetch } from "./run-id.ts";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1";
const MODEL = "openai/gpt-6-astra";

export async function generateMoodQueries(request: Request, moodText: string, context?: string): Promise<string[]> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new Error("AI is not configured");

  const runIdFetch = createLovableAiGatewayRunIdFetch(
    request.headers.get("X-Lovable-AIG-Run-ID")?.trim() || undefined,
  );
  const provider = createOpenAI({
    baseURL: GATEWAY_URL,
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: runIdFetch.fetch,
  });

  const messages: ModelMessage[] = [{ role: "user", content: context ? `Listener situation: ${moodText}\n\nWhat we remember about them: ${context}` : moodText }];

  const result = streamText({
    model: provider.responses(MODEL),
    system:
      "You are the music brain of VIVEK MUSIX, an Indian music streaming app (Telugu, Hindi, English). " +
      "The listener describes their situation, mood or music taste, plus what we remember about them (language, favourite artists, time of day). Match the situation's exact feeling, energy and tempo (e.g. gym = high-energy mass beats, heartbreak = sad melodies, devotional = bhakti songs). Lean on their language and favourite artists. Reply with ONLY a JSON array of 6 to 8 short music search query strings. " +
      "Most queries should be REAL, specific song titles (optionally with the film or singer) that clearly fit the situation; the rest can be short descriptive searches like 'telugu sad melody songs'. " +
      "Keep EVERY query on-theme: e.g. study = calm instrumental, lo-fi and soft melodies only, never party or item songs. Prefer Indian film music and popular Indian artists unless the listener clearly asks for something else. " +
      "No explanation, no markdown, just the JSON array.",
    messages,
    abortSignal: request.signal,
    providerOptions: {
      openai: {
        store: false,
        forceReasoning: true,
        reasoningEffort: "low",
        reasoningSummary: "auto",
        include: ["reasoning.encrypted_content"],
      },
    },
  });

  const text = await result.text;
  const match = text.match(/\[[\s\S]*\]/);
  if (!match) throw new Error("AI did not return a playlist plan");
  const parsed = JSON.parse(match[0]) as unknown;
  if (!Array.isArray(parsed)) throw new Error("AI returned an invalid playlist plan");
  return parsed.filter((q): q is string => typeof q === "string" && q.trim().length > 0).slice(0, 8);
}
