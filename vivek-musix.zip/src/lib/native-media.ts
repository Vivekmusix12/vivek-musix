/**
 * Android bridge: inside the Capacitor APK, the single global <audio> player reports its state to the
 * native Media3 foreground service (VivekPlaybackService), which shows the notification / lock screen
 * and forwards media buttons back here. On the website this is a no-op (browser Media Session is used).
 */
type Meta = { title: string; artist: string; album: string; artwork: { src: string; sizes?: string; type?: string }[] };
type Handlers = { play: () => void; pause: () => void; next: () => void; prev: () => void; seek: (t: number) => void };
type Cmd = { action: "play" | "pause" | "next" | "prev" | "seek"; position: number };
type VivekMediaPlugin = {
  update: (o: Record<string, unknown>) => Promise<void>;
  addListener: (e: "command", cb: (c: Cmd) => void) => Promise<{ remove: () => Promise<void> }>;
};

let modP: Promise<VivekMediaPlugin | null> | null = null;
function load() {
  if (typeof window === "undefined") return Promise.resolve(null);
  if (!modP) {
    modP = import("@capacitor/core")
      .then((c) => (c.Capacitor.isNativePlatform() ? c.registerPlugin<VivekMediaPlugin>("VivekMedia") : null))
      .catch(() => null);
  }
  return modP;
}

export async function nativeMeta(m: Meta) {
  const p = await load(); if (!p) return;
  await p.update({ title: m.title, artist: m.artist, album: m.album, artwork: m.artwork[m.artwork.length - 1]?.src ?? "" }).catch(() => {});
}
export async function nativeState(playing: boolean) {
  const p = await load(); if (!p) return;
  await p.update({ playing }).catch(() => {});
}
export async function nativePosition(duration: number, position: number) {
  const p = await load(); if (!p) return;
  await p.update({ duration, position: Math.min(position, duration) }).catch(() => {});
}
let sub: { remove: () => Promise<void> } | null = null;
export async function nativeHandlers(h: Handlers) {
  const p = await load(); if (!p) return;
  if (sub) await sub.remove().catch(() => {});
  sub = await p.addListener("command", (c) => {
    if (c.action === "play") h.play();
    else if (c.action === "pause") h.pause();
    else if (c.action === "next") h.next();
    else if (c.action === "prev") h.prev();
    else if (c.action === "seek") h.seek(c.position);
  }).catch(() => null);
}
