import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { z } from "zod";

export const getMoodQueries = createServerFn({ method: "POST" })
  .validator((data) => z.object({ mood: z.string().min(1).max(300), context: z.string().max(800).optional() }).parse(data))
  .handler(async ({ data }) => {
    const { generateMoodQueries } = await import("./ai/mood.server");
    return generateMoodQueries(getRequest(), data.mood, data.context);
  });
