// IndexedDB storage for downloaded songs (audio blob + song info) so they play offline.
const DB = "vivek-musix";
const STORE = "downloads";

function open(): Promise<IDBDatabase> {
  return new Promise((res, rej) => {
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(STORE, { keyPath: "id" });
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}

export type Stored<T> = { id: string; song: T; blob: Blob; savedAt: number };

async function tx<R>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<R>): Promise<R> {
  const db = await open();
  return new Promise((res, rej) => {
    const req = fn(db.transaction(STORE, mode).objectStore(STORE));
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}

export const saveDownload = <T>(item: Stored<T>) => tx("readwrite", (s) => s.put(item));
export const getDownload = <T>(id: string) => tx<Stored<T> | undefined>("readonly", (s) => s.get(id) as IDBRequest<Stored<T> | undefined>);
export const removeDownload = (id: string) => tx("readwrite", (s) => s.delete(id));
export const listDownloads = <T>() => tx<Stored<T>[]>("readonly", (s) => s.getAll() as IDBRequest<Stored<T>[]>);

export async function fetchWithProgress(url: string, onProgress: (p: number) => void): Promise<Blob> {
  const r = await fetch(url);
  if (!r.ok || !r.body) throw new Error("Download failed");
  const total = Number(r.headers.get("content-length")) || 0;
  const reader = r.body.getReader();
  const chunks: BlobPart[] = [];
  let got = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value as BlobPart);
    got += value.length;
    if (total) onProgress(got / total);
  }
  return new Blob(chunks, { type: r.headers.get("content-type") ?? "audio/mp4" });
}
