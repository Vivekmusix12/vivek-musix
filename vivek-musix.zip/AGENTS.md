<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the shared music-player state in the existing music screen when changing its visual layout, so playback, queue, and library controls stay synchronized.

- The app is music-only: no YouTube or video playback, to keep it light and smooth.
- Jam (listen-together) uses Lovable Cloud realtime broadcast/presence channels keyed by a short code, with no database tables; the first member in a room advances songs when a track ends.
- The Android APK bundles its own static copy of the app (ANDROID_BUILD=1 SPA build + scripts/android-shell.mjs → dist/client → cap sync); it never loads the published site, so server-only features must fail soft in the APK.
- Inside VivekMusix, list helpers (SongRow, DlBtn) are called as plain functions, never as `<Inline />` components — inline component types remount every row on each render and freeze phones.
- Network calls go through getJSON (cache, in-flight dedupe, timeout, backoff on 429/5xx, 20s failure cache) — never call the music API with raw fetch, so a struggling API isn't hammered.
