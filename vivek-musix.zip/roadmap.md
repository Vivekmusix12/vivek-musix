# Roadmap
- [x] Fix: next song doesn't auto-play when a song ends; player disappears/stops.
- [x] Remove YouTube video entirely (music only).
- [x] Smoothness: lighter artwork images, fewer heavy blur/animation effects.
- [x] Jam: create/join a shared listening session by code; everyone hears the same song and can change songs.
